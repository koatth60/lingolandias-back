"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3Service = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const lib_storage_1 = require("@aws-sdk/lib-storage");
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const fs_1 = require("fs");
let S3Service = class S3Service {
    constructor(configService) {
        this.configService = configService;
        this.s3Client = new client_s3_1.S3Client({
            region: this.configService.get('AWS_REGION'),
            credentials: {
                accessKeyId: this.configService.get('AWS_ACCESS_KEY_ID'),
                secretAccessKey: this.configService.get('AWS_SECRET_ACCESS_KEY'),
            },
        });
    }
    async uploadFile(file) {
        const bucketName = this.configService.get('AWS_BUCKET_NAME');
        const region = this.configService.get('AWS_REGION');
        const folderPrefix = 'avatar-images/';
        const fileKey = `${folderPrefix}${file.originalname}`;
        const uploadParams = {
            Bucket: bucketName,
            Key: fileKey,
            Body: file.buffer,
            ContentType: file.mimetype,
        };
        try {
            await this.s3Client.send(new client_s3_1.PutObjectCommand(uploadParams));
            const publicUrl = `https://${bucketName}.s3.${region}.amazonaws.com/${fileKey}`;
            return {
                success: true,
                url: publicUrl,
            };
        }
        catch (error) {
            throw new Error('Error al subir archivo a S3');
        }
    }
    async uploadChatFile(file) {
        const bucketName = this.configService.get('AWS_BUCKET_NAME');
        const region = this.configService.get('AWS_REGION');
        const folderPrefix = 'chat-uploads/';
        const fileKey = `${folderPrefix}${Date.now()}-${file.originalname}`;
        const uploadParams = {
            Bucket: bucketName,
            Key: fileKey,
            Body: file.buffer,
            ContentType: file.mimetype,
        };
        try {
            await this.s3Client.send(new client_s3_1.PutObjectCommand(uploadParams));
            const publicUrl = `https://${bucketName}.s3.${region}.amazonaws.com/${fileKey}`;
            return {
                success: true,
                url: publicUrl,
            };
        }
        catch (error) {
            throw new Error('Error uploading file to S3');
        }
    }
    async uploadRecording(file, teacherName, teacherEmail, role) {
        const bucketName = this.configService.get('AWS_BUCKET_NAME');
        const region = this.configService.get('AWS_REGION');
        const rawFolder = role === 'admin'
            ? 'others'
            : (teacherEmail || teacherName || 'unknown');
        const subfolder = rawFolder.replace(/[^a-zA-Z0-9._-]/g, '_');
        const fileKey = `recordings/${subfolder}/${file.originalname}`;
        const stream = (0, fs_1.createReadStream)(file.path);
        await new lib_storage_1.Upload({
            client: this.s3Client,
            queueSize: 4,
            partSize: 10 * 1024 * 1024,
            params: {
                Bucket: bucketName,
                Key: fileKey,
                Body: stream,
                ContentType: 'video/webm',
            },
        }).done();
        await Promise.allSettled([
            this.s3Client.send(new client_s3_1.PutObjectCommand({
                Bucket: bucketName,
                Key: 'recordings/.keep',
                Body: Buffer.from(''),
                ContentType: 'application/octet-stream',
            })),
            this.s3Client.send(new client_s3_1.PutObjectCommand({
                Bucket: bucketName,
                Key: `recordings/${subfolder}/.keep`,
                Body: Buffer.from(''),
                ContentType: 'application/octet-stream',
            })),
        ]);
        const url = `https://${bucketName}.s3.${region}.amazonaws.com/${fileKey}`;
        return { key: fileKey, url };
    }
    async listRecordings() {
        const bucketName = this.configService.get('AWS_BUCKET_NAME');
        const region = this.configService.get('AWS_REGION');
        const response = await this.s3Client.send(new client_s3_1.ListObjectsV2Command({ Bucket: bucketName, Prefix: 'recordings/' }));
        const items = (response.Contents || [])
            .filter((obj) => obj.Key !== 'recordings/' && !obj.Key.endsWith('/.keep'))
            .map((obj) => {
            const parts = obj.Key.split('/');
            const teacher = parts[1] || 'unknown';
            const filename = parts.slice(2).join('/');
            return {
                key: obj.Key,
                teacher,
                filename,
                size: obj.Size,
                lastModified: obj.LastModified,
                url: `https://${bucketName}.s3.${region}.amazonaws.com/${obj.Key}`,
            };
        });
        const grouped = items.reduce((acc, item) => {
            if (!acc[item.teacher])
                acc[item.teacher] = [];
            acc[item.teacher].push(item);
            return acc;
        }, {});
        const result = {};
        for (const [key, recs] of Object.entries(grouped)) {
            let displayName;
            if (key === 'others') {
                displayName = 'Others';
            }
            else {
                const firstFilename = recs[0]?.filename || '';
                const firstPart = firstFilename.split('_')[0];
                displayName = firstPart || key;
            }
            result[key] = { displayName, recordings: recs };
        }
        return result;
    }
    async deleteRecording(key) {
        const bucketName = this.configService.get('AWS_BUCKET_NAME');
        await this.s3Client.send(new client_s3_1.DeleteObjectCommand({ Bucket: bucketName, Key: key }));
        return { success: true };
    }
};
exports.S3Service = S3Service;
exports.S3Service = S3Service = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], S3Service);
//# sourceMappingURL=upload-files.service.js.map
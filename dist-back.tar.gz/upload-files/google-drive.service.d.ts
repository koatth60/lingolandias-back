import { ConfigService } from '@nestjs/config';
export declare class GoogleDriveService {
    private readonly configService;
    private drive;
    constructor(configService: ConfigService);
    uploadRecording(file: Express.Multer.File): Promise<string>;
}

import { ConfigService } from '@nestjs/config';
export declare class S3Service {
    private readonly configService;
    private readonly s3Client;
    constructor(configService: ConfigService);
    uploadFile(file: Express.Multer.File): Promise<{
        success: boolean;
        url: string;
    }>;
    uploadChatFile(file: Express.Multer.File): Promise<{
        success: boolean;
        url: string;
    }>;
    uploadRecording(file: Express.Multer.File, teacherName: string, teacherEmail: string, role: string): Promise<{
        key: string;
        url: string;
    }>;
    listRecordings(): Promise<Record<string, {
        displayName: string;
        recordings: any[];
    }>>;
    deleteRecording(key: string): Promise<{
        success: boolean;
    }>;
}

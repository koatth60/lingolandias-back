"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleDriveService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const googleapis_1 = require("googleapis");
const fs = require("fs");
let GoogleDriveService = class GoogleDriveService {
    constructor(configService) {
        this.configService = configService;
        const auth = new googleapis_1.google.auth.GoogleAuth({
            credentials: {
                client_email: this.configService.get('GOOGLE_CLIENT_EMAIL'),
                private_key: this.configService
                    .get('GOOGLE_PRIVATE_KEY')
                    ?.replace(/\\n/g, '\n'),
            },
            scopes: ['https://www.googleapis.com/auth/drive.file'],
        });
        this.drive = googleapis_1.google.drive({ version: 'v3', auth });
    }
    async uploadRecording(file) {
        const folderId = this.configService.get('GOOGLE_DRIVE_FOLDER_ID');
        const fileStream = fs.createReadStream(file.path);
        const uploaded = await this.drive.files.create({
            requestBody: {
                name: file.originalname,
                mimeType: 'video/webm',
                parents: folderId ? [folderId] : [],
            },
            media: {
                mimeType: 'video/webm',
                body: fileStream,
            },
            fields: 'id, webViewLink',
        });
        await this.drive.permissions.create({
            fileId: uploaded.data.id,
            requestBody: {
                role: 'reader',
                type: 'anyone',
            },
        });
        return uploaded.data.webViewLink;
    }
};
exports.GoogleDriveService = GoogleDriveService;
exports.GoogleDriveService = GoogleDriveService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], GoogleDriveService);
//# sourceMappingURL=google-drive.service.js.map
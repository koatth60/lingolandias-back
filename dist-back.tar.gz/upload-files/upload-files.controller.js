"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const multer_1 = require("multer");
const os = require("os");
const fs = require("fs");
const upload_files_service_1 = require("./upload-files.service");
const users_repository_1 = require("../users/users.repository");
let UploadController = class UploadController {
    constructor(s3Service, usersRepository) {
        this.s3Service = s3Service;
        this.usersRepository = usersRepository;
    }
    async uploadFile(file, userId) {
        if (!file) {
            throw new common_1.HttpException('No file provided', common_1.HttpStatus.BAD_REQUEST);
        }
        try {
            const uploadResult = await this.s3Service.uploadFile(file);
            const updatedUser = await this.usersRepository.updateUserProfileImage(userId, uploadResult.url);
            return {
                message: 'File uploaded successfully and user profile updated',
                user: updatedUser,
            };
        }
        catch (error) {
            throw new common_1.HttpException('Error uploading file and updating user profile', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async uploadChatFile(file, userId) {
        if (!file) {
            throw new common_1.HttpException('No file provided', common_1.HttpStatus.BAD_REQUEST);
        }
        const allowedMimeTypes = [
            'image/jpeg',
            'image/png',
            'application/pdf',
            'audio/mpeg',
            'audio/wav',
            'text/plain',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-powerpoint',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'video/mp4',
            'audio/mp3',
            'video/x-msvideo',
            'video/quicktime',
            'application/zip',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ];
        if (!allowedMimeTypes.includes(file.mimetype)) {
            throw new common_1.HttpException('File type not supported', common_1.HttpStatus.BAD_REQUEST);
        }
        try {
            const uploadResult = await this.s3Service.uploadChatFile(file);
            return {
                message: 'File uploaded successfully',
                fileUrl: uploadResult.url,
            };
        }
        catch (error) {
            throw new common_1.HttpException('Error uploading file', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async uploadRecording(file, teacherName, teacherEmail, role) {
        if (!file) {
            throw new common_1.HttpException('No file provided', common_1.HttpStatus.BAD_REQUEST);
        }
        try {
            const result = await this.s3Service.uploadRecording(file, teacherName, teacherEmail, role);
            try {
                fs.unlinkSync(file.path);
            }
            catch { }
            return { url: result.url, key: result.key };
        }
        catch (error) {
            console.error('Recording upload error:', error);
            try {
                if (file?.path)
                    fs.unlinkSync(file.path);
            }
            catch { }
            throw new common_1.HttpException('Error uploading recording', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async listRecordings() {
        try {
            return await this.s3Service.listRecordings();
        }
        catch (error) {
            console.error('List recordings error:', error);
            throw new common_1.HttpException('Error listing recordings', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async deleteRecording(key) {
        if (!key) {
            throw new common_1.HttpException('No key provided', common_1.HttpStatus.BAD_REQUEST);
        }
        try {
            return await this.s3Service.deleteRecording(key);
        }
        catch (error) {
            console.error('Delete recording error:', error);
            throw new common_1.HttpException('Error deleting recording', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.UploadController = UploadController;
__decorate([
    (0, common_1.Post)('file'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadFile", null);
__decorate([
    (0, common_1.Post)('chat-upload'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadChatFile", null);
__decorate([
    (0, common_1.Post)('recording'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: (0, multer_1.diskStorage)({
            destination: (_req, _file, cb) => cb(null, os.tmpdir()),
            filename: (_req, _file, cb) => cb(null, `lingo-rec-${Date.now()}.webm`),
        }),
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('teacherName')),
    __param(2, (0, common_1.Body)('teacherEmail')),
    __param(3, (0, common_1.Body)('role')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadRecording", null);
__decorate([
    (0, common_1.Get)('recordings'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "listRecordings", null);
__decorate([
    (0, common_1.Delete)('recording'),
    __param(0, (0, common_1.Body)('key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "deleteRecording", null);
exports.UploadController = UploadController = __decorate([
    (0, common_1.Controller)('upload'),
    __metadata("design:paramtypes", [upload_files_service_1.S3Service,
        users_repository_1.UsersRepository])
], UploadController);
//# sourceMappingURL=upload-files.controller.js.map
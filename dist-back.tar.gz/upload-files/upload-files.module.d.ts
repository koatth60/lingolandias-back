export declare class UploadFilesModule {
}

import { S3Service } from './upload-files.service';
import { UsersRepository } from 'src/users/users.repository';
export declare class UploadController {
    private readonly s3Service;
    private readonly usersRepository;
    constructor(s3Service: S3Service, usersRepository: UsersRepository);
    uploadFile(file: Express.Multer.File, userId: string): Promise<{
        message: string;
        user: import("../users/entities/user.entity").User;
    }>;
    uploadChatFile(file: Express.Multer.File, userId: string): Promise<{
        message: string;
        fileUrl: string;
    }>;
    uploadRecording(file: Express.Multer.File, teacherName: string, teacherEmail: string, role: string): Promise<{
        url: string;
        key: string;
    }>;
    listRecordings(): Promise<Record<string, {
        displayName: string;
        recordings: any[];
    }>>;
    deleteRecording(key: string): Promise<{
        success: boolean;
    }>;
}

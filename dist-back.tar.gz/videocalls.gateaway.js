"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoCallsGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const socket_io_1 = require("socket.io");
const chats_repository_1 = require("./chat/chats.repository");
const chat_entity_1 = require("./chat/entities/chat.entity");
const common_1 = require("@nestjs/common");
const global_chat_entity_1 = require("./chat/entities/global-chat.entity");
const counter_strategies_1 = require("./chat/strategies/counter-strategies");
const unread_counter_service_1 = require("./chat/unread-counter.service");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const user_entity_1 = require("./users/entities/user.entity");
let VideoCallsGateway = class VideoCallsGateway {
    constructor(chatsRepository, unreadCounterService, userRepo) {
        this.chatsRepository = chatsRepository;
        this.unreadCounterService = unreadCounterService;
        this.userRepo = userRepo;
        this.counterStrategies = [
            counter_strategies_1.supportRoomStrategy,
            counter_strategies_1.generalLanguageStrategy,
            counter_strategies_1.teacherLanguageStrategy,
            counter_strategies_1.randomRoomStrategy,
        ];
        this.validLanguages = new Set(['english', 'spanish', 'polish']);
        this.uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        this.socketToUser = new Map();
        this.userSockets = new Map();
    }
    async onModuleInit() {
        try {
            await this.userRepo.update({}, { online: 'offline' });
        }
        catch (_) { }
    }
    handleConnection(socket) { }
    async handleDisconnect(socket) {
        const userId = this.socketToUser.get(socket.id);
        if (!userId)
            return;
        this.socketToUser.delete(socket.id);
        const sockets = this.userSockets.get(userId);
        if (sockets) {
            sockets.delete(socket.id);
            if (sockets.size === 0) {
                this.userSockets.delete(userId);
                try {
                    const user = await this.userRepo.findOne({ where: { id: userId } });
                    if (user) {
                        user.online = 'offline';
                        await this.userRepo.save(user);
                        this.server.emit('userStatus', {
                            id: user.id,
                            online: 'offline',
                            name: user.name + ' ' + user.lastName,
                        });
                    }
                }
                catch (_) { }
            }
        }
    }
    handleRegisterUser(socket, data) {
        const { userId } = data;
        if (!userId)
            return;
        this.socketToUser.set(socket.id, userId);
        if (!this.userSockets.has(userId)) {
            this.userSockets.set(userId, new Set());
        }
        this.userSockets.get(userId).add(socket.id);
    }
    notifyUserOnline(user) {
        const { id, name } = user;
        this.server.emit('userStatus', { id: id, online: 'online', name: name });
    }
    notifyUserOffline(user) {
        const { id, name } = user;
        this.server.emit('userStatus', { id: id, online: 'offline', name: name });
    }
    notifyScheduleUpdated(payload) {
        this.server.emit('scheduleUpdated', payload);
    }
    notifyStudentAssigned(payload) {
        this.server.emit('studentAssigned', payload);
    }
    notifyStudentRemoved(payload) {
        this.server.emit('studentRemoved', payload);
    }
    handleJoinRoom(socket, data) {
        try {
            const rooms = Array.from(socket.rooms);
            rooms.forEach((room) => {
                if (room !== socket.id) {
                    socket.leave(room);
                }
            });
            socket.join(data.room);
            socket.broadcast.to(data.room).emit('ready', { username: data.username });
        }
        catch (err) {
        }
    }
    handleWebRTCSignaling(socket, data) {
        const { type, room } = data;
        if (['offer', 'answer', 'candidate'].includes(type)) {
            socket.broadcast.to(room).emit('data', data);
        }
        else {
        }
    }
    async handleEditNormalChat(socket, data) {
        try {
            await this.chatsRepository.editNormalChat(data.messageId, data.newMessage);
            this.server.to(data.room).emit('normalChatEdited', { messageId: data.messageId, newMessage: data.newMessage });
        }
        catch (err) { }
    }
    async handleEditGlobalChat(socket, data) {
        try {
            await this.chatsRepository.editGlobalChat(data.messageId, data.newMessage);
            this.server.to(data.room).emit('globalChatEdited', { messageId: data.messageId, newMessage: data.newMessage });
        }
        catch (err) { }
    }
    async handleClearNormalChat(socket, data) {
        try {
            await this.chatsRepository.deleteChatsByRoom(data.room);
            this.server.to(data.room).emit('normalChatCleared', { room: data.room });
        }
        catch (err) { }
    }
    handleNotifyRead(socket, data) {
        socket.broadcast.to(data.room).emit('chatMessagesRead', { room: data.room });
    }
    async handleDeleteGlobalChat(socket, data) {
        try {
            await this.chatsRepository.deleteGlobalChat(data.messageId);
            this.server
                .to(data.room)
                .emit('globalChatDeleted', { messageId: data.messageId });
        }
        catch (err) {
        }
    }
    async handleDeleteNormalChat(socket, data) {
        try {
            await this.chatsRepository.deleteNormalChat(data.messageId);
            this.server
                .to(data.room)
                .emit('normalChatDeleted', { messageId: data.messageId });
        }
        catch (err) {
        }
    }
    async handleChat(socket, data) {
        try {
            const chatData = new chat_entity_1.Chat();
            chatData.username = data.username;
            chatData.email = data.email;
            chatData.room = data.room;
            chatData.message = data.message;
            chatData.timestamp = new Date();
            if (data.userUrl) {
                chatData.userUrl = data.userUrl;
            }
            await this.chatsRepository.saveChat(chatData);
            this.server.to(data.room).emit('chat', chatData);
            socket.broadcast.emit('newChat', { room: data.room });
        }
        catch (err) {
        }
    }
    async handleGlobalChat(socket, data) {
        try {
            const globalChatData = new global_chat_entity_1.GlobalChat();
            globalChatData.username = data.username;
            globalChatData.email = data.email;
            globalChatData.room = data.room;
            globalChatData.message = data.message;
            globalChatData.timestamp = new Date();
            if (data.userUrl) {
                globalChatData.userUrl = data.userUrl;
            }
            await this.chatsRepository.saveGlobalChat(globalChatData);
            const strategy = this.counterStrategies.find((s) => s.roomPattern.test(data.room));
            if (strategy) {
                const counterField = this.getCounterField(data.room);
                await this.unreadCounterService.bulkIncrementCounter(counterField, (qb) => strategy.applyConditions(qb, data.room), data.email);
            }
            this.server.to(data.room).emit('globalChat', globalChatData);
            socket.broadcast.emit('newUnreadGlobalMessage', { room: data.room });
        }
        catch (err) {
        }
    }
    async handleSupportChat(socket, data) {
        try {
            const globalChatData = new global_chat_entity_1.GlobalChat();
            globalChatData.username = data.username;
            globalChatData.email = data.email;
            globalChatData.room = 'uuid-support';
            globalChatData.message = data.message;
            globalChatData.timestamp = new Date();
            if (data.userRole)
                globalChatData.userRole = data.userRole;
            if (data.userUrl)
                globalChatData.userUrl = data.userUrl;
            await this.chatsRepository.saveGlobalChat(globalChatData);
            await this.unreadCounterService.bulkIncrementCounter('supportRoom', (qb) => counter_strategies_1.supportRoomStrategy.applyConditions(qb, 'uuid-support'), data.email);
            this.server.to('uuid-support').emit('supportChat', globalChatData);
            socket.broadcast.emit('newUnreadSupportMessage', { room: 'uuid-support' });
        }
        catch (err) { }
    }
    async handleDeleteSupportChat(socket, data) {
        try {
            await this.chatsRepository.deleteGlobalChat(data.messageId);
            this.server.to('uuid-support').emit('supportChatDeleted', { messageId: data.messageId });
        }
        catch (err) { }
    }
    getCounterField(room) {
        if (room === 'uuid-support')
            return 'supportRoom';
        if (room.startsWith('uuid-teacher-')) {
            const lang = room.split('-')[2];
            return `teachers${this.capitalize(lang)}Room`;
        }
        if (room.startsWith('uuid-')) {
            const lang = room.split('-')[1];
            return `general${this.capitalize(lang)}Room`;
        }
        return 'randomRoom';
    }
    capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
    parseId(input) {
        if (this.isValidUUID(input)) {
            return { id: input };
        }
        if (input.startsWith('uuid-')) {
            const suffix = input.slice(5);
            const parts = suffix.split('-');
            if (parts.length === 1) {
                return { language: parts[0] };
            }
            if (parts.length === 2) {
                return { role: parts[0], language: parts[1] };
            }
        }
    }
    isValidUUID(uuid) {
        return this.uuidRegex.test(uuid);
    }
};
exports.VideoCallsGateway = VideoCallsGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], VideoCallsGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)('registerUser'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", void 0)
], VideoCallsGateway.prototype, "handleRegisterUser", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('join'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", void 0)
], VideoCallsGateway.prototype, "handleJoinRoom", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('data'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", void 0)
], VideoCallsGateway.prototype, "handleWebRTCSignaling", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('editNormalChat'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VideoCallsGateway.prototype, "handleEditNormalChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('editGlobalChat'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VideoCallsGateway.prototype, "handleEditGlobalChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('clearNormalChat'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VideoCallsGateway.prototype, "handleClearNormalChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('notifyRead'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", void 0)
], VideoCallsGateway.prototype, "handleNotifyRead", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('deleteGlobalChat'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VideoCallsGateway.prototype, "handleDeleteGlobalChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('deleteNormalChat'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VideoCallsGateway.prototype, "handleDeleteNormalChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('chat'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VideoCallsGateway.prototype, "handleChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('globalChat'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VideoCallsGateway.prototype, "handleGlobalChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('supportChat'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VideoCallsGateway.prototype, "handleSupportChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('deleteSupportChat'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VideoCallsGateway.prototype, "handleDeleteSupportChat", null);
exports.VideoCallsGateway = VideoCallsGateway = __decorate([
    (0, common_1.Injectable)({ scope: common_1.Scope.DEFAULT }),
    (0, websockets_1.WebSocketGateway)({
        cors: {
            origin: '*',
        },
    }),
    __param(2, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [chats_repository_1.ChatsRepository,
        unread_counter_service_1.UnreadCounterService,
        typeorm_2.Repository])
], VideoCallsGateway);
//# sourceMappingURL=videocalls.gateaway.js.map
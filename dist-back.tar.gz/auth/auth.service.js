"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const users_repository_1 = require("../users/users.repository");
const bcrypt = require("bcrypt");
const jwt_1 = require("@nestjs/jwt");
const videocalls_gateaway_1 = require("../videocalls.gateaway");
const mail_service_1 = require("../mail/mail.service");
const typeorm_1 = require("@nestjs/typeorm");
const unread_global_messages_entity_1 = require("../chat/entities/unread-global-messages.entity");
const typeorm_2 = require("typeorm");
const dotenv_1 = require("dotenv");
(0, dotenv_1.config)({ path: '.env.development' });
let AuthService = class AuthService {
    constructor(usersRepository, jwtService, videoCallsGateway, mailService, unReadGlobalMessageRepo) {
        this.usersRepository = usersRepository;
        this.jwtService = jwtService;
        this.videoCallsGateway = videoCallsGateway;
        this.mailService = mailService;
        this.unReadGlobalMessageRepo = unReadGlobalMessageRepo;
    }
    async register(newUser) {
        const foundUser = await this.usersRepository.findByEmail(newUser.email);
        if (foundUser) {
            throw new common_1.BadRequestException('User already exists');
        }
        const unhasedPassword = newUser.password;
        const hashedPassword = await bcrypt.hash(newUser.password, 10);
        const unsavedReadMessageUser = await this.usersRepository.register({
            ...newUser,
            password: hashedPassword,
        });
        const unreadGlobalMessage = new unread_global_messages_entity_1.UnreadGlobalMessage();
        unreadGlobalMessage.user = unsavedReadMessageUser;
        unreadGlobalMessage.randomRoom = 0;
        unreadGlobalMessage.generalEnglishRoom = 0;
        unreadGlobalMessage.teachersEnglishRoom = 0;
        unreadGlobalMessage.generalSpanishRoom = 0;
        unreadGlobalMessage.teachersSpanishRoom = 0;
        unreadGlobalMessage.generalPolishRoom = 0;
        unreadGlobalMessage.teachersPolishRoom = 0;
        await this.unReadGlobalMessageRepo.save(unreadGlobalMessage);
        await this.mailService.sendUserWelcomeEmail(newUser.name, newUser.email, unhasedPassword);
        return newUser;
    }
    async login(email, password) {
        if (!email || !password) {
            throw new common_1.BadRequestException('Email and password are required');
        }
        const foundUser = await this.usersRepository.findByEmail(email);
        if (!foundUser) {
            throw new common_1.BadRequestException('User not found');
        }
        const isPasswordMatch = await bcrypt.compare(password, foundUser.password);
        if (!isPasswordMatch) {
            throw new common_1.BadRequestException('Invalid credentials');
        }
        foundUser.online = 'online';
        await this.usersRepository.save(foundUser);
        this.videoCallsGateway.notifyUserOnline({
            id: foundUser.id,
            name: foundUser.name + ' ' + foundUser.lastName,
        });
        const userWithSettings = await this.usersRepository.findByEmail(email);
        const userPayload = { email: userWithSettings.email, id: userWithSettings.id };
        const token = this.jwtService.sign(userPayload);
        return { token, user: userWithSettings };
    }
    async logout(userId) {
        const foundUser = await this.usersRepository.findById(userId);
        if (!foundUser) {
            throw new common_1.BadRequestException('User not found');
        }
        foundUser.online = 'offline';
        await this.usersRepository.save(foundUser);
        this.videoCallsGateway.notifyUserOffline({
            id: foundUser.id,
            name: foundUser.name + ' ' + foundUser.lastName,
        });
        return foundUser;
    }
    async forgotPassword(email) {
        const foundUser = await this.usersRepository.findByEmail(email);
        if (!foundUser) {
            return { message: 'User not found' };
        }
        const hashSnippet = foundUser.password.slice(-10);
        const secret = process.env.JWT_SECRET;
        const token = this.jwtService.sign({ id: foundUser.id, h: hashSnippet }, { secret: secret, expiresIn: '1h' });
        const frontendUrl = (process.env.FRONTEND_URL || '').replace(/\/$/, '');
        const resetUrl = `${frontendUrl}/reset-password?token=${token}`;
        await this.mailService.sendUserResetPasswordEmail(foundUser.name, foundUser.email, resetUrl);
        return { message: 'Reset link sent if email exists' };
    }
    async setNewPassword(token, newPassword, confirmPassword) {
        if (newPassword !== confirmPassword) {
            throw new common_1.BadRequestException('Passwords do not match');
        }
        let decoded;
        try {
            decoded = this.jwtService.verify(token, {
                secret: process.env.JWT_SECRET,
            });
        }
        catch (e) {
            throw new common_1.BadRequestException('Invalid or expired token');
        }
        const user = await this.usersRepository.findById(decoded.id);
        if (!user) {
            throw new common_1.BadRequestException('User not found');
        }
        const currentHashSnippet = user.password.slice(-10);
        if (currentHashSnippet !== decoded.h) {
            throw new common_1.BadRequestException('Token expired');
        }
        user.password = await bcrypt.hash(newPassword, 12);
        await this.usersRepository.save(user);
        return { message: 'Password updated successfully' };
    }
    async changePassword(userId, currentPassword, newPassword, confirmPassword) {
        if (newPassword !== confirmPassword) {
            throw new common_1.BadRequestException('New passwords do not match');
        }
        const user = await this.usersRepository.findById(userId);
        if (!user) {
            throw new common_1.BadRequestException('User not found');
        }
        const isMatch = await bcrypt.compare(currentPassword, user.password);
        if (!isMatch) {
            throw new common_1.BadRequestException('Current password is incorrect');
        }
        user.password = await bcrypt.hash(newPassword, 12);
        await this.usersRepository.save(user);
        await this.mailService.sendPasswordChangedEmail(user.name, user.email);
        return { message: 'Password changed successfully' };
    }
    async verifyResetToken(token) {
        try {
            const decoded = this.jwtService.verify(token, {
                secret: process.env.JWT_SECRET,
                ignoreExpiration: false,
            });
            const user = await this.usersRepository.findById(decoded.id);
            if (!user) {
                throw new common_1.BadRequestException('Invalid token');
            }
            const currentHashSnippet = user.password.slice(-10);
            if (currentHashSnippet !== decoded.h) {
                throw new common_1.BadRequestException('Token expired');
            }
            return {
                valid: true,
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                },
            };
        }
        catch (error) {
            throw new common_1.BadRequestException(error.message === 'jwt expired' ? 'Token expired' : 'Invalid token');
        }
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __param(4, (0, typeorm_1.InjectRepository)(unread_global_messages_entity_1.UnreadGlobalMessage)),
    __metadata("design:paramtypes", [users_repository_1.UsersRepository,
        jwt_1.JwtService,
        videocalls_gateaway_1.VideoCallsGateway,
        mail_service_1.MailService,
        typeorm_2.Repository])
], AuthService);
//# sourceMappingURL=auth.service.js.map
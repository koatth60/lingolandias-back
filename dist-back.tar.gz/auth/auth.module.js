"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthModule = void 0;
const common_1 = require("@nestjs/common");
const auth_service_1 = require("./auth.service");
const auth_controller_1 = require("./auth.controller");
const user_entity_1 = require("../users/entities/user.entity");
const typeorm_1 = require("@nestjs/typeorm");
const users_repository_1 = require("../users/users.repository");
const schedule_repository_1 = require("../users/schedule.repository");
const mail_service_1 = require("../mail/mail.service");
const users_module_1 = require("../users/users.module");
const chat_module_1 = require("../chat/chat.module");
const gateway_module_1 = require("../gateway/gateway.module");
let AuthModule = class AuthModule {
};
exports.AuthModule = AuthModule;
exports.AuthModule = AuthModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                user_entity_1.User,
                user_entity_1.Schedule,
            ]),
            users_module_1.UsersModule,
            chat_module_1.ChatModule,
            gateway_module_1.GatewayModule,
        ],
        controllers: [auth_controller_1.AuthController],
        providers: [
            auth_service_1.AuthService,
            users_repository_1.UsersRepository,
            schedule_repository_1.ScheduleRepository,
            mail_service_1.MailService,
        ],
    })
], AuthModule);
//# sourceMappingURL=auth.module.js.map
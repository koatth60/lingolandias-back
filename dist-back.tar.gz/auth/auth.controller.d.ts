import { AuthService } from './auth.service';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    register(newUser: any): Promise<any>;
    login(credentials: any): Promise<{
        token: string;
        user: import("../users/entities/user.entity").User;
    }>;
    logout(userId: string): Promise<import("../users/entities/user.entity").User>;
    forgotPassword(email: string): Promise<{
        message: string;
    }>;
    resetPassword(resetPasswordDto: ResetPasswordDto): Promise<{
        message: string;
    }>;
    changePassword(changePasswordDto: ChangePasswordDto): Promise<{
        message: string;
    }>;
    verifyResetToken(token: string): Promise<{
        valid: boolean;
        user: {
            id: string;
            name: string;
            email: string;
        };
    }>;
}

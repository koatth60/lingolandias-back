import { UsersRepository } from 'src/users/users.repository';
import { JwtService } from '@nestjs/jwt';
import { VideoCallsGateway } from 'src/videocalls.gateaway';
import { MailService } from 'src/mail/mail.service';
import { UnreadGlobalMessage } from 'src/chat/entities/unread-global-messages.entity';
import { Repository } from 'typeorm';
export declare class AuthService {
    private readonly usersRepository;
    private readonly jwtService;
    private readonly videoCallsGateway;
    private readonly mailService;
    private readonly unReadGlobalMessageRepo;
    constructor(usersRepository: UsersRepository, jwtService: JwtService, videoCallsGateway: VideoCallsGateway, mailService: MailService, unReadGlobalMessageRepo: Repository<UnreadGlobalMessage>);
    register(newUser: any): Promise<any>;
    login(email: string, password: any): Promise<{
        token: string;
        user: import("../users/entities/user.entity").User;
    }>;
    logout(userId: string): Promise<import("../users/entities/user.entity").User>;
    forgotPassword(email: string): Promise<{
        message: string;
    }>;
    setNewPassword(token: string, newPassword: string, confirmPassword: string): Promise<{
        message: string;
    }>;
    changePassword(userId: string, currentPassword: string, newPassword: string, confirmPassword: string): Promise<{
        message: string;
    }>;
    verifyResetToken(token: string): Promise<{
        valid: boolean;
        user: {
            id: string;
            name: string;
            email: string;
        };
    }>;
}

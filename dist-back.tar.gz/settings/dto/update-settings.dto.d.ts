export declare class UpdateSettingsDto {
    darkMode?: boolean;
    notificationSound?: boolean;
    language?: string;
    classReminders?: boolean;
}

export declare class SettingsModule {
}

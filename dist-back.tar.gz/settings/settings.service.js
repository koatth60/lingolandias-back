"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const settings_entity_1 = require("../users/entities/settings.entity");
const user_entity_1 = require("../users/entities/user.entity");
let SettingsService = class SettingsService {
    constructor(settingsRepository, userRepository) {
        this.settingsRepository = settingsRepository;
        this.userRepository = userRepository;
    }
    async update(userId, updateSettingsDto) {
        const user = await this.userRepository.findOne({
            where: { id: userId },
            relations: ['settings'],
        });
        if (!user) {
            throw new common_1.NotFoundException('User not found');
        }
        if (!user.settings) {
            const newSettings = this.settingsRepository.create({
                ...updateSettingsDto,
                user,
            });
            await this.settingsRepository.save(newSettings);
            return newSettings;
        }
        Object.assign(user.settings, updateSettingsDto);
        return this.settingsRepository.save(user.settings);
    }
};
exports.SettingsService = SettingsService;
exports.SettingsService = SettingsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(settings_entity_1.Settings)),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], SettingsService);
//# sourceMappingURL=settings.service.js.map
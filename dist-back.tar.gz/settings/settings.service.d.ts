import { Repository } from 'typeorm';
import { Settings } from '../users/entities/settings.entity';
import { UpdateSettingsDto } from './dto/update-settings.dto';
import { User } from 'src/users/entities/user.entity';
export declare class SettingsService {
    private readonly settingsRepository;
    private readonly userRepository;
    constructor(settingsRepository: Repository<Settings>, userRepository: Repository<User>);
    update(userId: string, updateSettingsDto: UpdateSettingsDto): Promise<Settings>;
}

import { SettingsService } from './settings.service';
import { UpdateSettingsDto } from './dto/update-settings.dto';
export declare class SettingsController {
    private readonly settingsService;
    constructor(settingsService: SettingsService);
    update(request: any, updateSettingsDto: UpdateSettingsDto): Promise<import("../users/entities/settings.entity").Settings>;
}

export declare class GatewayModule {
}

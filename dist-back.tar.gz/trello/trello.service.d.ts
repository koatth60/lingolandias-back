import { Repository } from 'typeorm';
import { TrelloBoard } from './entities/trello-board.entity';
import { TrelloList } from './entities/trello-list.entity';
import { TrelloCard } from './entities/trello-card.entity';
export declare class TrelloService {
    private boardRepo;
    private listRepo;
    private cardRepo;
    constructor(boardRepo: Repository<TrelloBoard>, listRepo: Repository<TrelloList>, cardRepo: Repository<TrelloCard>);
    getBoardsByUser(userId: string): Promise<TrelloBoard[]>;
    getAllBoardsWithTeachers(): Promise<TrelloBoard[]>;
    createBoard(data: {
        name: string;
        background: string;
        fontFamily: string;
        userId: string;
        description?: string;
    }): Promise<TrelloBoard>;
    updateBoard(id: string, data: Partial<{
        name: string;
        background: string;
        fontFamily: string;
        description: string;
    }>): Promise<TrelloBoard>;
    deleteBoard(id: string): Promise<void>;
    getListsByBoard(boardId: string): Promise<TrelloList[]>;
    createList(boardId: string, name: string): Promise<TrelloList>;
    updateList(id: string, data: Partial<{
        name: string;
        position: number;
    }>): Promise<TrelloList>;
    deleteList(id: string): Promise<void>;
    createCard(listId: string, data: {
        name: string;
        description?: string;
        dueDate?: Date;
        label?: string;
    }): Promise<TrelloCard>;
    updateCard(id: string, data: Partial<{
        name: string;
        description: string;
        dueDate: Date;
        label: string;
        listId: string;
        position: number;
        checklist: string;
        comments: string;
        titleStyle: string;
    }>): Promise<TrelloCard>;
    deleteCard(id: string): Promise<void>;
    moveCard(cardId: string, targetListId: string, position: number): Promise<TrelloCard>;
    reorderLists(boardId: string, orderedIds: string[]): Promise<void>;
    reorderCards(listId: string, orderedIds: string[]): Promise<void>;
}

import { TrelloBoard } from './trello-board.entity';
import { TrelloCard } from './trello-card.entity';
export declare class TrelloList {
    id: string;
    name: string;
    position: number;
    boardId: string;
    board: TrelloBoard;
    createdAt: Date;
    cards: TrelloCard[];
}

import { TrelloList } from './trello-list.entity';
export declare class TrelloBoard {
    id: string;
    name: string;
    background: string;
    fontFamily: string;
    userId: string;
    description: string;
    position: number;
    createdAt: Date;
    updatedAt: Date;
    lists: TrelloList[];
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrelloList = void 0;
const typeorm_1 = require("typeorm");
const trello_board_entity_1 = require("./trello-board.entity");
const trello_card_entity_1 = require("./trello-card.entity");
let TrelloList = class TrelloList {
};
exports.TrelloList = TrelloList;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], TrelloList.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], TrelloList.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], TrelloList.prototype, "position", void 0);
__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], TrelloList.prototype, "boardId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => trello_board_entity_1.TrelloBoard, (board) => board.lists, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'boardId' }),
    __metadata("design:type", trello_board_entity_1.TrelloBoard)
], TrelloList.prototype, "board", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], TrelloList.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => trello_card_entity_1.TrelloCard, (card) => card.list, {
        cascade: true,
        onDelete: 'CASCADE',
    }),
    __metadata("design:type", Array)
], TrelloList.prototype, "cards", void 0);
exports.TrelloList = TrelloList = __decorate([
    (0, typeorm_1.Entity)('trello_lists')
], TrelloList);
//# sourceMappingURL=trello-list.entity.js.map
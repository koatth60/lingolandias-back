import { TrelloList } from './trello-list.entity';
export declare class TrelloCard {
    id: string;
    name: string;
    description: string;
    position: number;
    listId: string;
    list: TrelloList;
    dueDate: Date;
    label: string;
    checklist: string;
    comments: string;
    titleStyle: string;
    createdAt: Date;
    updatedAt: Date;
}

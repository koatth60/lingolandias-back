"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrelloBoard = void 0;
const typeorm_1 = require("typeorm");
const trello_list_entity_1 = require("./trello-list.entity");
let TrelloBoard = class TrelloBoard {
};
exports.TrelloBoard = TrelloBoard;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], TrelloBoard.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], TrelloBoard.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', default: '#0079BF' }),
    __metadata("design:type", String)
], TrelloBoard.prototype, "background", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', default: 'Inter' }),
    __metadata("design:type", String)
], TrelloBoard.prototype, "fontFamily", void 0);
__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], TrelloBoard.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, nullable: true }),
    __metadata("design:type", String)
], TrelloBoard.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], TrelloBoard.prototype, "position", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], TrelloBoard.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)(),
    __metadata("design:type", Date)
], TrelloBoard.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => trello_list_entity_1.TrelloList, (list) => list.board, {
        cascade: true,
        onDelete: 'CASCADE',
    }),
    __metadata("design:type", Array)
], TrelloBoard.prototype, "lists", void 0);
exports.TrelloBoard = TrelloBoard = __decorate([
    (0, typeorm_1.Entity)('trello_boards')
], TrelloBoard);
//# sourceMappingURL=trello-board.entity.js.map
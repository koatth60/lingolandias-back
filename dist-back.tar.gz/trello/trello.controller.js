"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrelloController = void 0;
const common_1 = require("@nestjs/common");
const trello_service_1 = require("./trello.service");
let TrelloController = class TrelloController {
    constructor(trelloService) {
        this.trelloService = trelloService;
    }
    async getBoards(userId) {
        const boards = await this.trelloService.getBoardsByUser(userId);
        return { success: true, boards };
    }
    async createBoard(name, background, fontFamily, userId, description) {
        const board = await this.trelloService.createBoard({
            name,
            background: background || '#0079BF',
            fontFamily: fontFamily || 'Inter',
            userId,
            description,
        });
        return { success: true, board };
    }
    async updateBoard(id, data) {
        const board = await this.trelloService.updateBoard(id, data);
        return { success: true, board };
    }
    async deleteBoard(id) {
        await this.trelloService.deleteBoard(id);
        return { success: true };
    }
    async getLists(boardId) {
        const lists = await this.trelloService.getListsByBoard(boardId);
        return { success: true, lists };
    }
    async createList(boardId, name) {
        const list = await this.trelloService.createList(boardId, name);
        return { success: true, list };
    }
    async updateList(id, data) {
        const list = await this.trelloService.updateList(id, data);
        return { success: true, list };
    }
    async deleteList(id) {
        await this.trelloService.deleteList(id);
        return { success: true };
    }
    async reorderLists(boardId, orderedIds) {
        await this.trelloService.reorderLists(boardId, orderedIds);
        return { success: true };
    }
    async createCard(listId, data) {
        const card = await this.trelloService.createCard(listId, data);
        return { success: true, card };
    }
    async updateCard(id, data) {
        const card = await this.trelloService.updateCard(id, data);
        return { success: true, card };
    }
    async deleteCard(id) {
        await this.trelloService.deleteCard(id);
        return { success: true };
    }
    async moveCard(id, listId, position) {
        const card = await this.trelloService.moveCard(id, listId, position);
        return { success: true, card };
    }
    async reorderCards(listId, orderedIds) {
        await this.trelloService.reorderCards(listId, orderedIds);
        return { success: true };
    }
    async getAllBoards() {
        const boards = await this.trelloService.getAllBoardsWithTeachers();
        return { success: true, boards };
    }
};
exports.TrelloController = TrelloController;
__decorate([
    (0, common_1.Get)('boards'),
    __param(0, (0, common_1.Query)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "getBoards", null);
__decorate([
    (0, common_1.Post)('boards'),
    __param(0, (0, common_1.Body)('name')),
    __param(1, (0, common_1.Body)('background')),
    __param(2, (0, common_1.Body)('fontFamily')),
    __param(3, (0, common_1.Body)('userId')),
    __param(4, (0, common_1.Body)('description')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "createBoard", null);
__decorate([
    (0, common_1.Put)('boards/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "updateBoard", null);
__decorate([
    (0, common_1.Delete)('boards/:id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "deleteBoard", null);
__decorate([
    (0, common_1.Get)('boards/:boardId/lists'),
    __param(0, (0, common_1.Param)('boardId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "getLists", null);
__decorate([
    (0, common_1.Post)('boards/:boardId/lists'),
    __param(0, (0, common_1.Param)('boardId')),
    __param(1, (0, common_1.Body)('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "createList", null);
__decorate([
    (0, common_1.Put)('lists/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "updateList", null);
__decorate([
    (0, common_1.Delete)('lists/:id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "deleteList", null);
__decorate([
    (0, common_1.Put)('boards/:boardId/lists/reorder'),
    __param(0, (0, common_1.Param)('boardId')),
    __param(1, (0, common_1.Body)('orderedIds')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Array]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "reorderLists", null);
__decorate([
    (0, common_1.Post)('lists/:listId/cards'),
    __param(0, (0, common_1.Param)('listId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "createCard", null);
__decorate([
    (0, common_1.Put)('cards/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "updateCard", null);
__decorate([
    (0, common_1.Delete)('cards/:id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "deleteCard", null);
__decorate([
    (0, common_1.Put)('cards/:id/move'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('listId')),
    __param(2, (0, common_1.Body)('position')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Number]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "moveCard", null);
__decorate([
    (0, common_1.Put)('lists/:listId/cards/reorder'),
    __param(0, (0, common_1.Param)('listId')),
    __param(1, (0, common_1.Body)('orderedIds')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Array]),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "reorderCards", null);
__decorate([
    (0, common_1.Get)('admin/boards'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TrelloController.prototype, "getAllBoards", null);
exports.TrelloController = TrelloController = __decorate([
    (0, common_1.Controller)('trello'),
    __metadata("design:paramtypes", [trello_service_1.TrelloService])
], TrelloController);
//# sourceMappingURL=trello.controller.js.map
import { TrelloService } from './trello.service';
export declare class TrelloController {
    private readonly trelloService;
    constructor(trelloService: TrelloService);
    getBoards(userId: string): Promise<{
        success: boolean;
        boards: import("./entities/trello-board.entity").TrelloBoard[];
    }>;
    createBoard(name: string, background: string, fontFamily: string, userId: string, description: string): Promise<{
        success: boolean;
        board: import("./entities/trello-board.entity").TrelloBoard;
    }>;
    updateBoard(id: string, data: {
        name?: string;
        background?: string;
        fontFamily?: string;
        description?: string;
    }): Promise<{
        success: boolean;
        board: import("./entities/trello-board.entity").TrelloBoard;
    }>;
    deleteBoard(id: string): Promise<{
        success: boolean;
    }>;
    getLists(boardId: string): Promise<{
        success: boolean;
        lists: import("./entities/trello-list.entity").TrelloList[];
    }>;
    createList(boardId: string, name: string): Promise<{
        success: boolean;
        list: import("./entities/trello-list.entity").TrelloList;
    }>;
    updateList(id: string, data: {
        name?: string;
        position?: number;
    }): Promise<{
        success: boolean;
        list: import("./entities/trello-list.entity").TrelloList;
    }>;
    deleteList(id: string): Promise<{
        success: boolean;
    }>;
    reorderLists(boardId: string, orderedIds: string[]): Promise<{
        success: boolean;
    }>;
    createCard(listId: string, data: {
        name: string;
        description?: string;
        dueDate?: Date;
        label?: string;
    }): Promise<{
        success: boolean;
        card: import("./entities/trello-card.entity").TrelloCard;
    }>;
    updateCard(id: string, data: {
        name?: string;
        description?: string;
        dueDate?: Date;
        label?: string;
        listId?: string;
        position?: number;
        checklist?: string;
        comments?: string;
        titleStyle?: string;
    }): Promise<{
        success: boolean;
        card: import("./entities/trello-card.entity").TrelloCard;
    }>;
    deleteCard(id: string): Promise<{
        success: boolean;
    }>;
    moveCard(id: string, listId: string, position: number): Promise<{
        success: boolean;
        card: import("./entities/trello-card.entity").TrelloCard;
    }>;
    reorderCards(listId: string, orderedIds: string[]): Promise<{
        success: boolean;
    }>;
    getAllBoards(): Promise<{
        success: boolean;
        boards: import("./entities/trello-board.entity").TrelloBoard[];
    }>;
}

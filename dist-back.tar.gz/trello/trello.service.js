"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrelloService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const trello_board_entity_1 = require("./entities/trello-board.entity");
const trello_list_entity_1 = require("./entities/trello-list.entity");
const trello_card_entity_1 = require("./entities/trello-card.entity");
let TrelloService = class TrelloService {
    constructor(boardRepo, listRepo, cardRepo) {
        this.boardRepo = boardRepo;
        this.listRepo = listRepo;
        this.cardRepo = cardRepo;
    }
    async getBoardsByUser(userId) {
        return this.boardRepo.find({
            where: { userId },
            order: { position: 'ASC', createdAt: 'ASC' },
        });
    }
    async getAllBoardsWithTeachers() {
        return this.boardRepo.find({
            order: { userId: 'ASC', position: 'ASC' },
        });
    }
    async createBoard(data) {
        const count = await this.boardRepo.count({ where: { userId: data.userId } });
        const board = this.boardRepo.create({ ...data, position: count });
        return this.boardRepo.save(board);
    }
    async updateBoard(id, data) {
        const result = await this.boardRepo.update(id, data);
        if (result.affected === 0)
            throw new common_1.NotFoundException('Board not found');
        return this.boardRepo.findOne({ where: { id } });
    }
    async deleteBoard(id) {
        const result = await this.boardRepo.delete(id);
        if (result.affected === 0)
            throw new common_1.NotFoundException('Board not found');
    }
    async getListsByBoard(boardId) {
        return this.listRepo
            .createQueryBuilder('list')
            .leftJoinAndSelect('list.cards', 'card')
            .where('list.boardId = :boardId', { boardId })
            .orderBy('list.position', 'ASC')
            .addOrderBy('list.createdAt', 'ASC')
            .addOrderBy('card.position', 'ASC')
            .getMany();
    }
    async createList(boardId, name) {
        const count = await this.listRepo.count({ where: { boardId } });
        const list = this.listRepo.create({ name, boardId, position: count });
        const saved = await this.listRepo.save(list);
        saved.cards = [];
        return saved;
    }
    async updateList(id, data) {
        const result = await this.listRepo.update(id, data);
        if (result.affected === 0)
            throw new common_1.NotFoundException('List not found');
        return this.listRepo.findOne({ where: { id } });
    }
    async deleteList(id) {
        const result = await this.listRepo.delete(id);
        if (result.affected === 0)
            throw new common_1.NotFoundException('List not found');
    }
    async createCard(listId, data) {
        const count = await this.cardRepo.count({ where: { listId } });
        const card = this.cardRepo.create({ ...data, listId, position: count });
        return this.cardRepo.save(card);
    }
    async updateCard(id, data) {
        const result = await this.cardRepo.update(id, data);
        if (result.affected === 0)
            throw new common_1.NotFoundException('Card not found');
        return this.cardRepo.findOne({ where: { id } });
    }
    async deleteCard(id) {
        const result = await this.cardRepo.delete(id);
        if (result.affected === 0)
            throw new common_1.NotFoundException('Card not found');
    }
    async moveCard(cardId, targetListId, position) {
        const result = await this.cardRepo.update(cardId, { listId: targetListId, position });
        if (result.affected === 0)
            throw new common_1.NotFoundException('Card not found');
        return this.cardRepo.findOne({ where: { id: cardId } });
    }
    async reorderLists(boardId, orderedIds) {
        await Promise.all(orderedIds.map((id, i) => this.listRepo.update({ id, boardId }, { position: i })));
    }
    async reorderCards(listId, orderedIds) {
        await Promise.all(orderedIds.map((id, i) => this.cardRepo.update({ id, listId }, { position: i })));
    }
};
exports.TrelloService = TrelloService;
exports.TrelloService = TrelloService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(trello_board_entity_1.TrelloBoard)),
    __param(1, (0, typeorm_1.InjectRepository)(trello_list_entity_1.TrelloList)),
    __param(2, (0, typeorm_1.InjectRepository)(trello_card_entity_1.TrelloCard)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], TrelloService);
//# sourceMappingURL=trello.service.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrelloModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const trello_controller_1 = require("./trello.controller");
const trello_service_1 = require("./trello.service");
const trello_board_entity_1 = require("./entities/trello-board.entity");
const trello_list_entity_1 = require("./entities/trello-list.entity");
const trello_card_entity_1 = require("./entities/trello-card.entity");
let TrelloModule = class TrelloModule {
};
exports.TrelloModule = TrelloModule;
exports.TrelloModule = TrelloModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([trello_board_entity_1.TrelloBoard, trello_list_entity_1.TrelloList, trello_card_entity_1.TrelloCard])],
        controllers: [trello_controller_1.TrelloController],
        providers: [trello_service_1.TrelloService],
        exports: [trello_service_1.TrelloService],
    })
], TrelloModule);
//# sourceMappingURL=trello.module.js.map
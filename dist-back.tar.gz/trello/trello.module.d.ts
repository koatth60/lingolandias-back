export declare class TrelloModule {
}

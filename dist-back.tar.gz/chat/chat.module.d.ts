export declare class ChatModule {
}

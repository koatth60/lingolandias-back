"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatsRepository = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const chat_entity_1 = require("./entities/chat.entity");
const global_chat_entity_1 = require("./entities/global-chat.entity");
const unread_global_messages_entity_1 = require("./entities/unread-global-messages.entity");
const archived_chat_entity_1 = require("./entities/archived-chat.entity");
let ChatsRepository = class ChatsRepository {
    constructor(chatRepository, globalChatRepository, unreadGlobalChatRepository, archivedChatRepository) {
        this.chatRepository = chatRepository;
        this.globalChatRepository = globalChatRepository;
        this.unreadGlobalChatRepository = unreadGlobalChatRepository;
        this.archivedChatRepository = archivedChatRepository;
    }
    async getChats(room) {
        try {
            return await this.chatRepository
                .createQueryBuilder('chat')
                .where('chat.room = :room', { room })
                .orderBy('chat.timestamp', 'DESC')
                .take(50)
                .getMany();
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to fetch chats');
        }
    }
    async readChat(room, email) {
        try {
            await this.chatRepository
                .createQueryBuilder()
                .update(chat_entity_1.Chat)
                .set({ unread: false })
                .where('room = :room', { room })
                .andWhere('email != :email', { email })
                .execute();
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to mark messages as read');
        }
    }
    async getGlobalChats(room) {
        try {
            return await this.globalChatRepository
                .createQueryBuilder('globalChat')
                .where('globalChat.room = :room', { room })
                .orderBy('globalChat.timestamp', 'DESC')
                .take(50)
                .getMany();
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to fetch global chats');
        }
    }
    async saveChat(chat) {
        try {
            return await this.chatRepository.save(chat);
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to save chat');
        }
    }
    async saveGlobalChat(globalChat) {
        try {
            return await this.globalChatRepository.save(globalChat);
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to save global chat');
        }
    }
    async deleteGlobalChat(id) {
        try {
            await this.globalChatRepository.delete(id);
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to delete global chat');
        }
    }
    async deleteNormalChat(id) {
        try {
            await this.chatRepository.delete(id);
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to delete chat');
        }
    }
    async editNormalChat(id, message) {
        try {
            await this.chatRepository.update(id, { message });
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to edit chat');
        }
    }
    async editGlobalChat(id, message) {
        try {
            await this.globalChatRepository.update(id, { message });
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to edit global chat');
        }
    }
    async saveUnreadMessage(body) {
        return await this.unreadGlobalChatRepository.save(body);
    }
    async getUnreadGlobalMessages(id) {
        try {
            return await this.unreadGlobalChatRepository
                .createQueryBuilder('unreadGlobalMessage')
                .where('unreadGlobalMessage.userId = :id', { id })
                .getMany();
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to fetch unread messages');
        }
    }
    async deleteUnreadGlobalMessages(userId, room) {
        if (!userId || !room) {
            throw new common_1.NotFoundException('userId and room are required');
        }
        const roomMappings = {
            'uuid-english': 'generalEnglishRoom',
            'uuid-spanish': 'generalSpanishRoom',
            'uuid-polish': 'generalPolishRoom',
            'uuid-teacher-english': 'teachersEnglishRoom',
            'uuid-teacher-spanish': 'teachersSpanishRoom',
            'uuid-teacher-polish': 'teachersPolishRoom',
            'uuid-support': 'supportRoom',
        };
        let columnToUpdate = roomMappings[room];
        if (!columnToUpdate) {
            columnToUpdate = 'randomRoom';
        }
        if (!columnToUpdate) {
            throw new common_1.NotFoundException(`Room with ID ${room} not found`);
        }
        const user = await this.unreadGlobalChatRepository.findOne({
            where: { user: { id: userId } },
        });
        if (!user) {
            throw new common_1.NotFoundException(`User with ID ${userId} not found`);
        }
        await this.unreadGlobalChatRepository.update({ user: { id: userId } }, { [columnToUpdate]: 0 });
        return `Room ${room} has been reset to 0 for user ${userId}`;
    }
    findAllUsers() {
        return this.unreadGlobalChatRepository.find({
            relations: ['user', 'user.teacher'],
            select: {
                user: {
                    id: true,
                    email: true,
                    language: true,
                    role: true,
                    teacher: {
                        id: true,
                    },
                },
            },
        });
    }
    async getArchivedChats(room, page) {
        try {
            return await this.archivedChatRepository
                .createQueryBuilder('archived_chats')
                .where('archived_chats.room = :room', { room })
                .orderBy('archived_chats.timestamp', 'DESC')
                .take(50)
                .skip((page - 1) * 50)
                .getMany();
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to fetch archived chats');
        }
    }
    async getTeacherRoomSummary(rooms, teacherEmail) {
        if (!rooms.length)
            return { lastMessages: {}, unreadCounts: {} };
        const latestRows = await this.chatRepository
            .createQueryBuilder('chat')
            .select(['chat.room', 'chat.message', 'chat.userUrl', 'chat.email', 'chat.timestamp', 'chat.unread'])
            .distinctOn(['chat.room'])
            .where('chat.room IN (:...rooms)', { rooms })
            .orderBy('chat.room')
            .addOrderBy('chat.timestamp', 'DESC')
            .getMany();
        const unreadRows = await this.chatRepository
            .createQueryBuilder('chat')
            .select('chat.room', 'room')
            .addSelect('COUNT(*)', 'count')
            .where('chat.room IN (:...rooms)', { rooms })
            .andWhere('chat.unread = true')
            .andWhere('chat.email != :email', { email: teacherEmail })
            .groupBy('chat.room')
            .getRawMany();
        const lastMessages = {};
        for (const row of latestRows) {
            const isFile = Boolean(row.userUrl);
            lastMessages[row.room] = {
                content: isFile ? row.userUrl : row.message,
                timestamp: row.timestamp,
                type: isFile ? 'file' : 'text',
                sender: row.email,
                unread: row.unread,
                isFile,
            };
        }
        const unreadCounts = {};
        for (const row of unreadRows) {
            unreadCounts[row.room] = parseInt(row.count, 10);
        }
        return { lastMessages, unreadCounts };
    }
    async deleteChatsByRoom(room) {
        try {
            const chatDeleteResult = await this.chatRepository
                .createQueryBuilder()
                .delete()
                .from(chat_entity_1.Chat)
                .where('room = :room', { room })
                .execute();
            const archivedChatDeleteResult = await this.archivedChatRepository
                .createQueryBuilder()
                .delete()
                .from(archived_chat_entity_1.ArchivedChat)
                .where('room = :room', { room })
                .execute();
            return {
                chatsDeleted: chatDeleteResult.affected || 0,
                archivedChatsDeleted: archivedChatDeleteResult.affected || 0,
            };
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Failed to delete chats');
        }
    }
};
exports.ChatsRepository = ChatsRepository;
exports.ChatsRepository = ChatsRepository = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(1, (0, typeorm_1.InjectRepository)(global_chat_entity_1.GlobalChat)),
    __param(2, (0, typeorm_1.InjectRepository)(unread_global_messages_entity_1.UnreadGlobalMessage)),
    __param(3, (0, typeorm_1.InjectRepository)(archived_chat_entity_1.ArchivedChat)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], ChatsRepository);
//# sourceMappingURL=chats.repository.js.map
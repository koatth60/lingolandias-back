"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatModule = void 0;
const common_1 = require("@nestjs/common");
const chat_service_1 = require("./chat.service");
const chat_controller_1 = require("./chat.controller");
const chats_repository_1 = require("./chats.repository");
const chat_entity_1 = require("./entities/chat.entity");
const typeorm_1 = require("@nestjs/typeorm");
const global_chat_entity_1 = require("./entities/global-chat.entity");
const unread_global_messages_entity_1 = require("./entities/unread-global-messages.entity");
const unread_counter_service_1 = require("./unread-counter.service");
const counter_strategies_1 = require("./strategies/counter-strategies");
const archived_chat_entity_1 = require("./entities/archived-chat.entity");
const clean_chat_service_1 = require("./clean-chat.service");
let ChatModule = class ChatModule {
};
exports.ChatModule = ChatModule;
exports.ChatModule = ChatModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                chat_entity_1.Chat,
                global_chat_entity_1.GlobalChat,
                unread_global_messages_entity_1.UnreadGlobalMessage,
                archived_chat_entity_1.ArchivedChat,
            ]),
        ],
        controllers: [chat_controller_1.ChatController],
        providers: [
            chat_service_1.ChatService,
            chats_repository_1.ChatsRepository,
            unread_counter_service_1.UnreadCounterService,
            clean_chat_service_1.ChatCleanupService,
            unread_global_messages_entity_1.UnreadGlobalMessage,
            {
                provide: 'COUNTER_STRATEGIES',
                useValue: {
                    generalLanguageStrategy: counter_strategies_1.generalLanguageStrategy,
                    teacherLanguageStrategy: counter_strategies_1.teacherLanguageStrategy,
                    randomRoomStrategy: counter_strategies_1.randomRoomStrategy,
                },
            },
        ],
        exports: [
            chats_repository_1.ChatsRepository,
            unread_counter_service_1.UnreadCounterService,
            'COUNTER_STRATEGIES',
            typeorm_1.TypeOrmModule,
        ],
    })
], ChatModule);
//# sourceMappingURL=chat.module.js.map
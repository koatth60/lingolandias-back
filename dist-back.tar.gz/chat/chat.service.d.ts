import { Chat } from './entities/chat.entity';
import { ChatsRepository } from './chats.repository';
import { GlobalChat } from './entities/global-chat.entity';
import { UnreadGlobalMessage } from './entities/unread-global-messages.entity';
import { ArchivedChat } from './entities/archived-chat.entity';
export declare class ChatService {
    private readonly chatsRepositoy;
    constructor(chatsRepositoy: ChatsRepository);
    getChats(room: string): Promise<Chat[]>;
    readChat(room: string, email: string): Promise<void>;
    getGlobalChats(room: string): Promise<GlobalChat[]>;
    deleteGlobalChat(id: string): Promise<void>;
    deleteNormalChat(id: string): Promise<void>;
    getUnreadGlobalMessages(id: string): Promise<UnreadGlobalMessage[]>;
    deleteUnreadGlobalMessages(userId: string, room: string): Promise<string>;
    getArchivedChats(room: string, page: number): Promise<ArchivedChat[]>;
    deleteChatsByRoom(room: string): Promise<{
        chatsDeleted: number;
        archivedChatsDeleted: number;
    }>;
    getTeacherRoomSummary(rooms: string[], teacherEmail: string): Promise<{
        lastMessages: Record<string, any>;
        unreadCounts: Record<string, number>;
    }>;
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.randomRoomStrategy = exports.supportRoomStrategy = exports.teacherLanguageStrategy = exports.generalLanguageStrategy = void 0;
const typeorm_1 = require("typeorm");
exports.generalLanguageStrategy = {
    roomPattern: /^uuid-(english|spanish|polish)$/,
    applyConditions: (qb, room) => {
        const language = room.split('-')[1];
        qb.andWhere(new typeorm_1.Brackets((subQb) => {
            subQb
                .where('user.language = :language', { language })
                .orWhere('user.role = :role', { role: 'admin' });
        }));
    },
};
exports.teacherLanguageStrategy = {
    roomPattern: /^uuid-teacher-(english|spanish|polish)$/,
    applyConditions: (qb, room) => {
        const language = room.split('-')[2];
        qb.andWhere(new typeorm_1.Brackets((subQb) => {
            subQb
                .where('user.language = :language', { language })
                .andWhere('user.role = :teacherRole', { teacherRole: 'teacher' })
                .orWhere('user.role = :adminRole', { adminRole: 'admin' });
        }));
    },
};
exports.supportRoomStrategy = {
    roomPattern: /^uuid-support$/,
    applyConditions: (qb) => {
        qb.andWhere(new typeorm_1.Brackets((subQb) => {
            subQb
                .where('user.role = :teacherRole', { teacherRole: 'teacher' })
                .orWhere('user.role = :adminRole', { adminRole: 'admin' });
        }));
    },
};
exports.randomRoomStrategy = {
    roomPattern: /^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$/i,
    applyConditions: (qb, room) => {
        qb.andWhere(new typeorm_1.Brackets((subQb) => {
            subQb
                .where('user.teacherId = :roomId', { roomId: room })
                .orWhere('user.id = :roomId', { roomId: room });
        }));
    },
};
//# sourceMappingURL=counter-strategies.js.map
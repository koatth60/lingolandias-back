import { SelectQueryBuilder } from 'typeorm';
import { UnreadGlobalMessage } from '../entities/unread-global-messages.entity';
export type CounterStrategy = {
    roomPattern: RegExp;
    applyConditions: (qb: SelectQueryBuilder<UnreadGlobalMessage>, room: string) => void;
};
export declare const generalLanguageStrategy: CounterStrategy;
export declare const teacherLanguageStrategy: CounterStrategy;
export declare const supportRoomStrategy: CounterStrategy;
export declare const randomRoomStrategy: CounterStrategy;

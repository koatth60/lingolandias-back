"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnreadCounterService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const unread_global_messages_entity_1 = require("./entities/unread-global-messages.entity");
let UnreadCounterService = class UnreadCounterService {
    constructor(unreadRepo) {
        this.unreadRepo = unreadRepo;
    }
    async bulkIncrementCounter(counterField, buildConditions, excludedEmail) {
        const subQuery = this.unreadRepo
            .createQueryBuilder('unread')
            .innerJoin('unread.user', 'user')
            .select('unread.id')
            .where('user.email != :excludedEmail', { excludedEmail });
        buildConditions(subQuery);
        const result = await this.unreadRepo
            .createQueryBuilder()
            .update(unread_global_messages_entity_1.UnreadGlobalMessage)
            .set({ [counterField]: () => `${counterField} + 1` })
            .where(`id IN (${subQuery.getQuery()})`)
            .setParameters(subQuery.getParameters())
            .execute();
        return result.affected || 0;
    }
};
exports.UnreadCounterService = UnreadCounterService;
exports.UnreadCounterService = UnreadCounterService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(unread_global_messages_entity_1.UnreadGlobalMessage)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], UnreadCounterService);
//# sourceMappingURL=unread-counter.service.js.map
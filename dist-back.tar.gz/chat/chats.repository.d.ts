import { Repository } from 'typeorm';
import { Chat } from './entities/chat.entity';
import { GlobalChat } from './entities/global-chat.entity';
import { UnreadGlobalMessage } from './entities/unread-global-messages.entity';
import { ArchivedChat } from './entities/archived-chat.entity';
export declare class ChatsRepository {
    private readonly chatRepository;
    private readonly globalChatRepository;
    private readonly unreadGlobalChatRepository;
    private readonly archivedChatRepository;
    constructor(chatRepository: Repository<Chat>, globalChatRepository: Repository<GlobalChat>, unreadGlobalChatRepository: Repository<UnreadGlobalMessage>, archivedChatRepository: Repository<ArchivedChat>);
    getChats(room: string): Promise<Chat[]>;
    readChat(room: string, email: string): Promise<void>;
    getGlobalChats(room: string): Promise<GlobalChat[]>;
    saveChat(chat: Chat): Promise<Chat>;
    saveGlobalChat(globalChat: GlobalChat): Promise<GlobalChat>;
    deleteGlobalChat(id: string): Promise<void>;
    deleteNormalChat(id: string): Promise<void>;
    editNormalChat(id: string, message: string): Promise<void>;
    editGlobalChat(id: string, message: string): Promise<void>;
    saveUnreadMessage(body: any): Promise<any>;
    getUnreadGlobalMessages(id: string): Promise<UnreadGlobalMessage[]>;
    deleteUnreadGlobalMessages(userId: string, room: string): Promise<string>;
    findAllUsers(): Promise<UnreadGlobalMessage[]>;
    getArchivedChats(room: string, page: number): Promise<ArchivedChat[]>;
    getTeacherRoomSummary(rooms: string[], teacherEmail: string): Promise<{
        lastMessages: Record<string, any>;
        unreadCounts: Record<string, number>;
    }>;
    deleteChatsByRoom(room: string): Promise<{
        chatsDeleted: number;
        archivedChatsDeleted: number;
    }>;
}

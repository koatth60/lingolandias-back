import { ChatService } from './chat.service';
import { DeleteUnreadDto } from './dtos/delete-unread-dto';
import { ReadChatDto } from './dtos/read-chat-dto';
import { GetArchivedChatsDto } from './dtos/get-archived-chats.dto';
export declare class ChatController {
    private readonly chatService;
    constructor(chatService: ChatService);
    getChats(room: string): Promise<import("./entities/chat.entity").Chat[]>;
    readChat(body: ReadChatDto): Promise<void>;
    getGlobalChats(room: string): Promise<import("./entities/global-chat.entity").GlobalChat[]>;
    deleteGlobalChat(id: string): Promise<void>;
    deleteNormalChat(id: string): Promise<void>;
    getUnreadGlobalMessages(id: string): Promise<import("./entities/unread-global-messages.entity").UnreadGlobalMessage[]>;
    deleteUnreadGlobalMessages(body: DeleteUnreadDto): Promise<string>;
    getArchivedChats(room: string, query: GetArchivedChatsDto): Promise<import("./entities/archived-chat.entity").ArchivedChat[]>;
    deleteChatsByStudent(studentId: string): Promise<{
        chatsDeleted: number;
        archivedChatsDeleted: number;
        message: string;
    }>;
    getTeacherSummary(roomsParam: string, email: string): Promise<{
        lastMessages: Record<string, any>;
        unreadCounts: Record<string, number>;
    }>;
}

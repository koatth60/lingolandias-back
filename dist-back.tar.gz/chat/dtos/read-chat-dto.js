"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReadChatDto = void 0;
class ReadChatDto {
}
exports.ReadChatDto = ReadChatDto;
//# sourceMappingURL=read-chat-dto.js.map
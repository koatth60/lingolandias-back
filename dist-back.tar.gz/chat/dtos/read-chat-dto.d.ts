export declare class ReadChatDto {
    room: string;
    email: string;
}

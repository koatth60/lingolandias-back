"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteUnreadDto = void 0;
class DeleteUnreadDto {
}
exports.DeleteUnreadDto = DeleteUnreadDto;
//# sourceMappingURL=delete-unread-dto.js.map
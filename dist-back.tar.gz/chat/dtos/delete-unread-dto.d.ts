export declare class DeleteUnreadDto {
    room: string;
    userId: string;
}

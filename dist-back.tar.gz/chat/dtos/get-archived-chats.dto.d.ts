export declare class GetArchivedChatsDto {
    page?: number;
}

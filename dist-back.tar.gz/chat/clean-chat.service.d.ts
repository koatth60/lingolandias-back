import { Repository } from 'typeorm';
import { ArchivedChat } from './entities/archived-chat.entity';
import { Chat } from './entities/chat.entity';
export declare class ChatCleanupService {
    private chatRepository;
    private archivedChatRepository;
    constructor(chatRepository: Repository<Chat>, archivedChatRepository: Repository<ArchivedChat>);
    archiveOldMessages(): Promise<void>;
    deleteOldArchivedChats(): Promise<void>;
}

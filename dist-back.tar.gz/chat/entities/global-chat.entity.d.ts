export declare class GlobalChat {
    id: string;
    username: string;
    email: string;
    avatarUrl?: string;
    room: string;
    message: string;
    userUrl?: string;
    userRole?: string;
    unreadCount: number;
    timestamp: Date;
}

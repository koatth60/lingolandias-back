export declare class ArchivedChat {
    id: string;
    username: string;
    email: string;
    room: string;
    message: string;
    timestamp: Date;
    archivedAt: Date;
}

import { User } from 'src/users/entities/user.entity';
export declare class UnreadGlobalMessage {
    id: string;
    user: User;
    randomRoom: number;
    generalEnglishRoom: number;
    teachersEnglishRoom: number;
    generalSpanishRoom: number;
    teachersSpanishRoom: number;
    generalPolishRoom: number;
    teachersPolishRoom: number;
    supportRoom: number;
}

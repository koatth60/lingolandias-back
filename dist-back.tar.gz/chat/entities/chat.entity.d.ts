export declare class Chat {
    id: string;
    username: string;
    email: string;
    avatarUrl?: string;
    room: string;
    message: string;
    userUrl?: string;
    unread: boolean;
    timestamp: Date;
}

import { Repository, SelectQueryBuilder } from 'typeorm';
import { UnreadGlobalMessage } from './entities/unread-global-messages.entity';
import { CounterField } from './types';
export declare class UnreadCounterService {
    private readonly unreadRepo;
    constructor(unreadRepo: Repository<UnreadGlobalMessage>);
    bulkIncrementCounter(counterField: CounterField, buildConditions: (qb: SelectQueryBuilder<UnreadGlobalMessage>) => void, excludedEmail: string): Promise<number>;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatCleanupService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const typeorm_1 = require("typeorm");
const typeorm_2 = require("@nestjs/typeorm");
const archived_chat_entity_1 = require("./entities/archived-chat.entity");
const chat_entity_1 = require("./entities/chat.entity");
let ChatCleanupService = class ChatCleanupService {
    constructor(chatRepository, archivedChatRepository) {
        this.chatRepository = chatRepository;
        this.archivedChatRepository = archivedChatRepository;
    }
    async archiveOldMessages() {
        const oneMonthAgo = new Date();
        oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
        const oldMessages = await this.chatRepository.find({
            where: { timestamp: (0, typeorm_1.LessThan)(oneMonthAgo) },
        });
        const archivedMessages = oldMessages.map((message) => ({
            ...message,
            archivedAt: new Date(),
        }));
        await this.archivedChatRepository.save(archivedMessages);
        await this.chatRepository.delete({
            timestamp: (0, typeorm_1.LessThan)(oneMonthAgo),
        });
    }
    async deleteOldArchivedChats() {
        const oneYearAgo = new Date();
        oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
        await this.archivedChatRepository.delete({
            archivedAt: (0, typeorm_1.LessThan)(oneYearAgo),
        });
    }
};
exports.ChatCleanupService = ChatCleanupService;
__decorate([
    (0, schedule_1.Cron)('0 0 * * *'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ChatCleanupService.prototype, "archiveOldMessages", null);
__decorate([
    (0, schedule_1.Cron)('0 1 * * *'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ChatCleanupService.prototype, "deleteOldArchivedChats", null);
exports.ChatCleanupService = ChatCleanupService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_2.InjectRepository)(chat_entity_1.Chat)),
    __param(1, (0, typeorm_2.InjectRepository)(archived_chat_entity_1.ArchivedChat)),
    __metadata("design:paramtypes", [typeorm_1.Repository,
        typeorm_1.Repository])
], ChatCleanupService);
//# sourceMappingURL=clean-chat.service.js.map
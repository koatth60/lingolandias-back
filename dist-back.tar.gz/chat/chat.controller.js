"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatController = void 0;
const common_1 = require("@nestjs/common");
const chat_service_1 = require("./chat.service");
const delete_unread_dto_1 = require("./dtos/delete-unread-dto");
const read_chat_dto_1 = require("./dtos/read-chat-dto");
const get_archived_chats_dto_1 = require("./dtos/get-archived-chats.dto");
let ChatController = class ChatController {
    constructor(chatService) {
        this.chatService = chatService;
    }
    async getChats(room) {
        return this.chatService.getChats(room);
    }
    async readChat(body) {
        const { room, email } = body;
        return this.chatService.readChat(room, email);
    }
    async getGlobalChats(room) {
        return this.chatService.getGlobalChats(room);
    }
    async deleteGlobalChat(id) {
        return this.chatService.deleteGlobalChat(id);
    }
    async deleteNormalChat(id) {
        return this.chatService.deleteNormalChat(id);
    }
    async getUnreadGlobalMessages(id) {
        return this.chatService.getUnreadGlobalMessages(id);
    }
    async deleteUnreadGlobalMessages(body) {
        const { room, userId } = body;
        return this.chatService.deleteUnreadGlobalMessages(userId, room);
    }
    async getArchivedChats(room, query) {
        return this.chatService.getArchivedChats(room, query.page);
    }
    async deleteChatsByStudent(studentId) {
        const result = await this.chatService.deleteChatsByRoom(studentId);
        return {
            message: 'Chats deleted successfully',
            ...result,
        };
    }
    async getTeacherSummary(roomsParam, email) {
        if (!roomsParam || !email) {
            throw new common_1.BadRequestException('rooms and email are required');
        }
        const rooms = roomsParam.split(',').filter(Boolean);
        return this.chatService.getTeacherRoomSummary(rooms, email);
    }
};
exports.ChatController = ChatController;
__decorate([
    (0, common_1.Get)('messages/:room'),
    __param(0, (0, common_1.Param)('room')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "getChats", null);
__decorate([
    (0, common_1.Patch)('read-chat'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [read_chat_dto_1.ReadChatDto]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "readChat", null);
__decorate([
    (0, common_1.Get)('global-chats/:room'),
    __param(0, (0, common_1.Param)('room')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "getGlobalChats", null);
__decorate([
    (0, common_1.Delete)('delete-global-chat/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "deleteGlobalChat", null);
__decorate([
    (0, common_1.Delete)('delete-normal-chat/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "deleteNormalChat", null);
__decorate([
    (0, common_1.Get)('unread-global-messages/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "getUnreadGlobalMessages", null);
__decorate([
    (0, common_1.Patch)('delete-unread-global-messages'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [delete_unread_dto_1.DeleteUnreadDto]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "deleteUnreadGlobalMessages", null);
__decorate([
    (0, common_1.Get)('archived-messages/:room'),
    __param(0, (0, common_1.Param)('room')),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, get_archived_chats_dto_1.GetArchivedChatsDto]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "getArchivedChats", null);
__decorate([
    (0, common_1.Delete)('delete-chats-by-student/:studentId'),
    __param(0, (0, common_1.Param)('studentId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "deleteChatsByStudent", null);
__decorate([
    (0, common_1.Get)('teacher-summary'),
    __param(0, (0, common_1.Query)('rooms')),
    __param(1, (0, common_1.Query)('email')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "getTeacherSummary", null);
exports.ChatController = ChatController = __decorate([
    (0, common_1.Controller)('chat'),
    __metadata("design:paramtypes", [chat_service_1.ChatService])
], ChatController);
//# sourceMappingURL=chat.controller.js.map
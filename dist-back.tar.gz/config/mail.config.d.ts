declare const _default: (() => {
    mailHost: string;
    smtpUsername: string;
    smtpPassword: string;
}) & import("@nestjs/config").ConfigFactoryKeyHost<{
    mailHost: string;
    smtpUsername: string;
    smtpPassword: string;
}>;
export default _default;

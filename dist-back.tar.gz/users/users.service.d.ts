import { UsersRepository } from './users.repository';
import { ScheduleRepository } from './schedule.repository';
import { VideoCallsGateway } from 'src/videocalls.gateaway';
export declare class UsersService {
    private readonly usersRepository;
    private readonly scheduleRepository;
    private readonly gateway;
    constructor(usersRepository: UsersRepository, scheduleRepository: ScheduleRepository, gateway: VideoCallsGateway);
    findAll(): Promise<import("./entities/user.entity").User[]>;
    findAdminDashboard(): Promise<{
        users: import("./entities/user.entity").User[];
        schedules: import("./entities/user.entity").Schedule[];
    }>;
    assignStudent(body: any): Promise<any>;
    remove(email: string): Promise<any>;
    update(updateUser: any): Promise<any>;
    removeStudentsFromTeacher(body: any): Promise<any>;
    modifySchedule(body: any): Promise<import("./entities/user.entity").Schedule>;
    removeEvents(body: {
        eventIds: string[];
        teacherId: string;
        studentId: string;
    }): Promise<string>;
    getStudentSchedules(studentId: string): Promise<import("./entities/user.entity").Schedule[]>;
    getStudentProfile(studentId: string): Promise<{
        teacher: {
            id: string;
            name: string;
            lastName: string;
            email: string;
            avatarUrl: string;
            role: string;
        };
        studentSchedules: import("./entities/user.entity").Schedule[];
    }>;
    addEvent(event: any): Promise<import("./entities/user.entity").Schedule>;
}

import { Schedule, User } from './entities/user.entity';
import { Repository } from 'typeorm';
import { UnreadGlobalMessage } from 'src/chat/entities/unread-global-messages.entity';
export declare class UsersRepository {
    private readonly usersRepository;
    private readonly scheduleRepository;
    private readonly unReadGlobalMessageRepo;
    constructor(usersRepository: Repository<User>, scheduleRepository: Repository<Schedule>, unReadGlobalMessageRepo: Repository<UnreadGlobalMessage>);
    findByEmail(email: string): Promise<User | undefined>;
    findById(id: string): Promise<User | undefined>;
    register(newUser: User): Promise<User>;
    login(email: string, password: string): Promise<User | undefined>;
    save(user: User): Promise<User>;
    findAll(): Promise<User[]>;
    findAdminDashboard(): Promise<{
        users: User[];
        schedules: Schedule[];
    }>;
    resetAllOnlineStatus(): Promise<void>;
    assignStudent(body: any): Promise<any>;
    remove(email: string): Promise<any>;
    update(updateUser: any): Promise<any>;
    updateUserProfileImage(userId: string, imageUrl: string): Promise<User>;
    removeStudentsFromTeacher(body: any): Promise<any>;
    find(): Promise<User[]>;
}

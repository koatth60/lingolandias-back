import { Repository } from 'typeorm';
import { Schedule } from './entities/user.entity';
export declare class ScheduleRepository {
    private readonly repository;
    constructor(repository: Repository<Schedule>);
    findAll(): Promise<Schedule[]>;
    findByStudentId(studentId: string): Promise<Schedule[]>;
    save(schedule: Schedule): Promise<Schedule>;
    modifySchedule(body: any): Promise<Schedule>;
    removeEvents(body: {
        eventIds: string[];
        teacherId: string;
        studentId: string;
    }): Promise<boolean>;
}

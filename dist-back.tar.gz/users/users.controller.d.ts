import { UsersService } from './users.service';
export declare class UsersController {
    private readonly usersService;
    constructor(usersService: UsersService);
    findAll(): Promise<import("./entities/user.entity").User[]>;
    adminDashboard(): Promise<{
        users: import("./entities/user.entity").User[];
        schedules: import("./entities/user.entity").Schedule[];
    }>;
    getStudentSchedules(studentId: string): Promise<import("./entities/user.entity").Schedule[]>;
    getStudentProfile(studentId: string): Promise<{
        teacher: {
            id: string;
            name: string;
            lastName: string;
            email: string;
            avatarUrl: string;
            role: string;
        };
        studentSchedules: import("./entities/user.entity").Schedule[];
    }>;
    assignStudent(body: any): Promise<any>;
    update(updateUser: any): Promise<any>;
    remove(body: any): Promise<any>;
    addEvent(body: any): Promise<import("./entities/user.entity").Schedule>;
    removeStudentsFromTeacher(body: any): Promise<any>;
    modifySchedule(body: any): Promise<import("./entities/user.entity").Schedule>;
    removeEvents(body: {
        eventIds: string[];
        teacherId: string;
        studentId: string;
    }): Promise<string>;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScheduleRepository = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const user_entity_1 = require("./entities/user.entity");
let ScheduleRepository = class ScheduleRepository {
    constructor(repository) {
        this.repository = repository;
    }
    async findAll() {
        return this.repository.find();
    }
    async findByStudentId(studentId) {
        return this.repository.find({ where: { studentId } });
    }
    async save(schedule) {
        return this.repository.save(schedule);
    }
    async modifySchedule(body) {
        const { eventId, start, end, newEvent } = body;
        const schedule = await this.repository.findOne({ where: { id: eventId } });
        if (!schedule) {
            throw new common_1.NotFoundException('Schedule not found');
        }
        const newStart = new Date(start);
        const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        schedule.startTime = newStart;
        schedule.endTime = new Date(end);
        schedule.initialDateTime = new Date(newEvent);
        schedule.dayOfWeek = dayNames[newStart.getUTCDay()];
        return await this.repository.save(schedule);
    }
    async removeEvents(body) {
        const { eventIds, teacherId, studentId } = body;
        const result = await this.repository
            .createQueryBuilder()
            .delete()
            .from(user_entity_1.Schedule)
            .where('id IN (:...eventIds)', { eventIds })
            .andWhere('teacherId = :teacherId', { teacherId })
            .andWhere('studentId = :studentId', { studentId })
            .execute();
        if (result.affected === 0) {
            throw new common_1.NotFoundException('Events not found');
        }
        return true;
    }
};
exports.ScheduleRepository = ScheduleRepository;
exports.ScheduleRepository = ScheduleRepository = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.Schedule)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], ScheduleRepository);
//# sourceMappingURL=schedule.repository.js.map
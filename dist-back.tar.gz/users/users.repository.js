"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersRepository = void 0;
const common_1 = require("@nestjs/common");
const user_entity_1 = require("./entities/user.entity");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const typeorm_3 = require("typeorm");
const bcrypt = require("bcrypt");
const unread_global_messages_entity_1 = require("../chat/entities/unread-global-messages.entity");
let UsersRepository = class UsersRepository {
    constructor(usersRepository, scheduleRepository, unReadGlobalMessageRepo) {
        this.usersRepository = usersRepository;
        this.scheduleRepository = scheduleRepository;
        this.unReadGlobalMessageRepo = unReadGlobalMessageRepo;
    }
    async findByEmail(email) {
        return await this.usersRepository.findOne({
            where: { email },
            relations: [
                'students',
                'teacher',
                'studentSchedules',
                'teacherSchedules',
                'settings',
            ],
        });
    }
    async findById(id) {
        return await this.usersRepository.findOne({
            where: { id },
            relations: [
                'students',
                'teacher',
                'studentSchedules',
                'teacherSchedules',
                'settings',
            ],
        });
    }
    async register(newUser) {
        return this.usersRepository.save(newUser);
    }
    async login(email, password) {
        const user = await this.usersRepository.findOne({
            where: { email },
            relations: [
                'students',
                'teacher',
                'studentSchedules',
                'teacherSchedules',
                'settings',
            ],
        });
        if (user && (await bcrypt.compare(password, user.password))) {
            return user;
        }
        return undefined;
    }
    async save(user) {
        return await this.usersRepository.save(user);
    }
    async findAll() {
        const users = await this.usersRepository.find({
            relations: [
                'students',
                'teacher',
                'studentSchedules',
                'teacherSchedules',
                'settings',
            ],
        });
        return users;
    }
    async findAdminDashboard() {
        const [users, schedules] = await Promise.all([
            this.usersRepository.find({ relations: ['settings'] }),
            this.scheduleRepository.find(),
        ]);
        return { users, schedules };
    }
    async resetAllOnlineStatus() {
        await this.usersRepository.update({}, { online: 'offline' });
    }
    async assignStudent(body) {
        const { teacherId, studentId, events } = body;
        const teacher = await this.usersRepository.findOne({
            where: { id: teacherId },
            relations: ['students', 'teacherSchedules'],
        });
        const student = await this.usersRepository.findOne({
            where: { id: studentId },
            relations: ['teacher', 'studentSchedules'],
        });
        if (!teacher || teacher.role !== 'teacher') {
            throw new Error('Teacher not found.');
        }
        if (!student || student.role !== 'user') {
            throw new Error('Student not found.');
        }
        teacher.students.push(student);
        student.teacher = teacher;
        const updatedEvents = events.map((event) => ({
            ...event,
            student,
            teacher,
            studentId,
            teacherId,
            startTime: new Date(event.start),
            endTime: new Date(event.end),
            initialDateTime: new Date(event.start),
        }));
        const savedSchedules = await this.scheduleRepository.save(updatedEvents);
        teacher.teacherSchedules = [...teacher.teacherSchedules, ...savedSchedules];
        student.studentSchedules = [...student.studentSchedules, ...savedSchedules];
        await this.usersRepository.save(teacher);
        await this.usersRepository.save(student);
        const plainSchedules = savedSchedules.map((s) => ({
            id: s.id,
            startTime: s.startTime,
            endTime: s.endTime,
            initialDateTime: s.initialDateTime,
            dayOfWeek: s.dayOfWeek,
            studentId: s.studentId,
            teacherId: s.teacherId,
            studentName: s.studentName,
            teacherName: s.teacherName,
        }));
        return {
            message: 'Teacher and student updated successfully with schedules',
            savedSchedules: plainSchedules,
            studentId,
            teacherId,
            student: {
                id: student.id,
                name: student.name,
                lastName: student.lastName,
                email: student.email,
                avatarUrl: student.avatarUrl,
                role: student.role,
            },
            teacher: {
                id: teacher.id,
                name: teacher.name,
                lastName: teacher.lastName,
                email: teacher.email,
                avatarUrl: teacher.avatarUrl,
                role: teacher.role,
            },
        };
    }
    async remove(email) {
        const user = await this.usersRepository.findOne({ where: { email } });
        if (!user) {
            return 'no user found';
        }
        await this.unReadGlobalMessageRepo.delete({
            user: { id: user.id },
        });
        const deletedUser = await this.usersRepository.delete({ email });
        return deletedUser;
    }
    async update(updateUser) {
        const { email, ...rest } = updateUser;
        const updatedUser = await this.usersRepository.update({ email }, rest);
        if (!updatedUser.affected) {
            return 'no user found';
        }
        return updatedUser;
    }
    async updateUserProfileImage(userId, imageUrl) {
        const user = await this.usersRepository.findOne({
            where: { id: userId },
            relations: [
                'students',
                'teacher',
                'studentSchedules',
                'teacherSchedules',
                'settings',
            ],
        });
        if (!user) {
            throw new Error('User not found');
        }
        user.avatarUrl = imageUrl;
        const updatedUser = await this.usersRepository.save(user);
        return updatedUser;
    }
    async removeStudentsFromTeacher(body) {
        const { teacherId, studentIds } = body;
        const teacher = await this.usersRepository.findOne({
            where: { id: teacherId },
            relations: ['students', 'teacherSchedules'],
        });
        if (!teacher || teacher.role !== 'teacher') {
            throw new Error('Teacher not found.');
        }
        const students = await this.usersRepository.find({
            where: { id: (0, typeorm_2.In)(studentIds) },
            relations: ['studentSchedules'],
        });
        if (!students || students.length === 0) {
            throw new Error('No students found.');
        }
        const deleteResult = await this.scheduleRepository.find({
            where: {
                teacherId: teacher.id,
                studentId: (0, typeorm_2.In)(studentIds),
            },
        });
        const idsToDelete = deleteResult.map((schedule) => schedule.id);
        if (idsToDelete.length > 0) {
            await this.scheduleRepository.delete(idsToDelete);
        }
        teacher.students = teacher.students.filter((student) => !studentIds.includes(student.id));
        students.forEach((student) => {
            student.teacher = null;
        });
        await this.usersRepository.save(teacher);
        await this.usersRepository.save(students);
        return {
            message: 'Students removed from teacher successfully, and schedules deleted.',
            deletedScheduleIds: idsToDelete,
            teacherId,
            studentIds,
        };
    }
    async find() {
        return await this.usersRepository.find();
    }
};
exports.UsersRepository = UsersRepository;
exports.UsersRepository = UsersRepository = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.Schedule)),
    __param(2, (0, typeorm_1.InjectRepository)(unread_global_messages_entity_1.UnreadGlobalMessage)),
    __metadata("design:paramtypes", [typeorm_3.Repository,
        typeorm_3.Repository,
        typeorm_3.Repository])
], UsersRepository);
//# sourceMappingURL=users.repository.js.map
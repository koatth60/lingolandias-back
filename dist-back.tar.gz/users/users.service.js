"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const users_repository_1 = require("./users.repository");
const schedule_repository_1 = require("./schedule.repository");
const videocalls_gateaway_1 = require("../videocalls.gateaway");
let UsersService = class UsersService {
    constructor(usersRepository, scheduleRepository, gateway) {
        this.usersRepository = usersRepository;
        this.scheduleRepository = scheduleRepository;
        this.gateway = gateway;
    }
    async findAll() {
        const users = await this.usersRepository.findAll();
        if (!users || users.length === 0) {
            throw new common_1.NotFoundException('No users found');
        }
        return users;
    }
    async findAdminDashboard() {
        return this.usersRepository.findAdminDashboard();
    }
    async assignStudent(body) {
        const result = await this.usersRepository.assignStudent(body);
        if (!result) {
            throw new common_1.NotFoundException('User not found');
        }
        this.gateway.notifyStudentAssigned({
            teacherId: result.teacherId,
            studentId: result.studentId,
            schedules: result.savedSchedules,
            student: result.student,
            teacher: result.teacher,
        });
        return result;
    }
    async remove(email) {
        const removedUser = await this.usersRepository.remove(email);
        if (!removedUser.affected) {
            throw new common_1.NotFoundException('User not found');
        }
        return removedUser;
    }
    async update(updateUser) {
        const updatedUser = await this.usersRepository.update(updateUser);
        if (!updatedUser.affected) {
            throw new common_1.NotFoundException('User not found');
        }
        return updatedUser;
    }
    async removeStudentsFromTeacher(body) {
        const result = await this.usersRepository.removeStudentsFromTeacher(body);
        if (!result) {
            throw new common_1.NotFoundException('Schedule not found');
        }
        this.gateway.notifyStudentRemoved({
            teacherId: result.teacherId,
            studentIds: result.studentIds,
            deletedScheduleIds: result.deletedScheduleIds,
        });
        return result;
    }
    async modifySchedule(body) {
        const updatedSchedule = await this.scheduleRepository.modifySchedule(body);
        if (!updatedSchedule) {
            throw new common_1.NotFoundException('Schedule not found');
        }
        this.gateway.notifyScheduleUpdated({
            studentId: updatedSchedule.studentId,
            action: 'modify',
            schedule: updatedSchedule,
        });
        return updatedSchedule;
    }
    async removeEvents(body) {
        const success = await this.scheduleRepository.removeEvents(body);
        if (!success) {
            throw new common_1.NotFoundException('Events not found');
        }
        this.gateway.notifyScheduleUpdated({
            studentId: body.studentId,
            action: 'remove',
            eventIds: body.eventIds,
        });
        return 'success';
    }
    async getStudentSchedules(studentId) {
        return this.scheduleRepository.findByStudentId(studentId);
    }
    async getStudentProfile(studentId) {
        const user = await this.usersRepository.findById(studentId);
        if (!user)
            throw new common_1.NotFoundException('Student not found');
        return {
            teacher: user.teacher
                ? {
                    id: user.teacher.id,
                    name: user.teacher.name,
                    lastName: user.teacher.lastName,
                    email: user.teacher.email,
                    avatarUrl: user.teacher.avatarUrl,
                    role: user.teacher.role,
                }
                : null,
            studentSchedules: user.studentSchedules,
        };
    }
    async addEvent(event) {
        const newEvent = {
            ...event,
            initialDateTime: new Date(event.initialDateTime),
            startTime: new Date(event.startTime),
            endTime: new Date(event.endTime),
        };
        const savedSchedule = await this.scheduleRepository.save(newEvent);
        if (!savedSchedule) {
            throw new common_1.NotFoundException('Failed to create event');
        }
        this.gateway.notifyScheduleUpdated({
            studentId: savedSchedule.studentId,
            action: 'add',
            schedule: savedSchedule,
        });
        return savedSchedule;
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [users_repository_1.UsersRepository,
        schedule_repository_1.ScheduleRepository,
        videocalls_gateaway_1.VideoCallsGateway])
], UsersService);
//# sourceMappingURL=users.service.js.map
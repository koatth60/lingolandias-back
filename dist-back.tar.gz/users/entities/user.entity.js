"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Schedule = exports.User = void 0;
const unread_global_messages_entity_1 = require("../../chat/entities/unread-global-messages.entity");
const typeorm_1 = require("typeorm");
const settings_entity_1 = require("./settings.entity");
let User = class User {
};
exports.User = User;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], User.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100 }),
    __metadata("design:type", String)
], User.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100 }),
    __metadata("design:type", String)
], User.prototype, "lastName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', unique: true }),
    __metadata("design:type", String)
], User.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], User.prototype, "password", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], User.prototype, "language", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['online', 'offline'], default: 'offline' }),
    __metadata("design:type", String)
], User.prototype, "online", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], User.prototype, "avatarUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], User.prototype, "biography", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], User.prototype, "country", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], User.prototype, "city", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], User.prototype, "postal", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], User.prototype, "address", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], User.prototype, "phone", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['user', 'teacher', 'admin'], default: 'user' }),
    __metadata("design:type", String)
], User.prototype, "role", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', default: '123e4567-e89b-12d3-a456-426614174000' }),
    __metadata("design:type", String)
], User.prototype, "teachersRoom", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', default: '123e4567-e89b-12d3-a456-426614174001' }),
    __metadata("design:type", String)
], User.prototype, "generalChat", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => Schedule, (schedule) => schedule.student, { nullable: true }),
    __metadata("design:type", Array)
], User.prototype, "studentSchedules", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => Schedule, (schedule) => schedule.teacher, {
        nullable: true,
    }),
    __metadata("design:type", Array)
], User.prototype, "teacherSchedules", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => User, (student) => student.teacher),
    __metadata("design:type", Array)
], User.prototype, "students", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => User, (teacher) => teacher.students, {
        nullable: true,
        onDelete: 'SET NULL',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'teacherId' }),
    __metadata("design:type", User)
], User.prototype, "teacher", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => unread_global_messages_entity_1.UnreadGlobalMessage, (unreadMessage) => unreadMessage.user),
    __metadata("design:type", Array)
], User.prototype, "unreadMessages", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => settings_entity_1.Settings, (settings) => settings.user, {
        cascade: true,
        onDelete: 'CASCADE'
    }),
    __metadata("design:type", settings_entity_1.Settings)
], User.prototype, "settings", void 0);
exports.User = User = __decorate([
    (0, typeorm_1.Entity)('users')
], User);
let Schedule = class Schedule {
};
exports.Schedule = Schedule;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], Schedule.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'timestamp',
        transformer: {
            from: (value) => (value ? new Date(value) : null),
            to: (value) => (value instanceof Date ? value.toISOString() : null),
        },
    }),
    __metadata("design:type", Date)
], Schedule.prototype, "initialDateTime", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'timestamp',
        transformer: {
            from: (value) => (value ? new Date(value) : null),
            to: (value) => (value instanceof Date ? value.toISOString() : null),
        },
    }),
    __metadata("design:type", Date)
], Schedule.prototype, "startTime", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'timestamp',
        transformer: {
            from: (value) => (value ? new Date(value) : null),
            to: (value) => (value instanceof Date ? value.toISOString() : null),
        },
    }),
    __metadata("design:type", Date)
], Schedule.prototype, "endTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], Schedule.prototype, "dayOfWeek", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], Schedule.prototype, "teacherName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], Schedule.prototype, "studentName", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", String)
], Schedule.prototype, "studentId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => User, (student) => student.studentSchedules, {
        nullable: false,
    }),
    (0, typeorm_1.ManyToOne)(() => User, (student) => student.studentSchedules, {
        nullable: true,
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'studentId' }),
    __metadata("design:type", User)
], Schedule.prototype, "student", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", String)
], Schedule.prototype, "teacherId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => User, (teacher) => teacher.teacherSchedules, {
        nullable: true,
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'teacherId' }),
    __metadata("design:type", User)
], Schedule.prototype, "teacher", void 0);
exports.Schedule = Schedule = __decorate([
    (0, typeorm_1.Entity)('schedules')
], Schedule);
//# sourceMappingURL=user.entity.js.map
import { UnreadGlobalMessage } from 'src/chat/entities/unread-global-messages.entity';
import { Settings } from './settings.entity';
export declare class User {
    id: string;
    name: string;
    lastName: string;
    email: string;
    password: string;
    language: string;
    online: string;
    avatarUrl: string;
    biography: string;
    country: string;
    city: string;
    postal: string;
    address: string;
    phone: string;
    role: string;
    teachersRoom: string;
    generalChat: string;
    studentSchedules: Schedule[];
    teacherSchedules: Schedule[];
    students: User[];
    teacher: User;
    unreadMessages: UnreadGlobalMessage[];
    settings: Settings;
}
export declare class Schedule {
    id: string;
    initialDateTime: Date;
    startTime: Date;
    endTime: Date;
    dayOfWeek: string;
    teacherName: string;
    studentName: string;
    studentId: string;
    student: User;
    teacherId: string;
    teacher: User;
}

import { User } from './user.entity';
export declare class Settings {
    id: string;
    darkMode: boolean;
    notificationSound: boolean;
    language: string;
    classReminders: boolean;
    user: User;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const app_controller_1 = require("./app.controller");
const app_service_1 = require("./app.service");
const typeorm_1 = require("./config/typeorm");
const config_1 = require("@nestjs/config");
const typeorm_2 = require("@nestjs/typeorm");
const auth_module_1 = require("./auth/auth.module");
const chat_module_1 = require("./chat/chat.module");
const jwt_1 = require("@nestjs/jwt");
const users_module_1 = require("./users/users.module");
const upload_files_module_1 = require("./upload-files/upload-files.module");
const mail_module_1 = require("./mail/mail.module");
const mail_config_1 = require("./config/mail.config");
const schedule_1 = require("@nestjs/schedule");
const settings_module_1 = require("./settings/settings.module");
const trello_module_1 = require("./trello/trello.module");
const push_module_1 = require("./push/push.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            schedule_1.ScheduleModule.forRoot(),
            config_1.ConfigModule.forRoot({
                isGlobal: true,
                load: [typeorm_1.default, mail_config_1.default],
            }),
            typeorm_2.TypeOrmModule.forRootAsync({
                inject: [config_1.ConfigService],
                useFactory: (configService) => configService.get('typeorm'),
            }),
            jwt_1.JwtModule.register({
                global: true,
                secret: process.env.JWT_SECRET,
                signOptions: { expiresIn: '8h' },
            }),
            auth_module_1.AuthModule,
            chat_module_1.ChatModule,
            users_module_1.UsersModule,
            upload_files_module_1.UploadFilesModule,
            mail_module_1.MailModule,
            settings_module_1.SettingsModule,
            trello_module_1.TrelloModule,
            push_module_1.PushModule,
        ],
        controllers: [app_controller_1.AppController],
        providers: [app_service_1.AppService],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map
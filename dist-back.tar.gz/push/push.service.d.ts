import { Repository } from 'typeorm';
import { PushSubscription } from './push-subscription.entity';
import { Schedule } from '../users/entities/user.entity';
export declare class PushService {
    private readonly subscriptionRepository;
    private readonly scheduleRepository;
    private readonly logger;
    constructor(subscriptionRepository: Repository<PushSubscription>, scheduleRepository: Repository<Schedule>);
    getVapidPublicKey(): {
        publicKey: string;
    };
    saveSubscription(userId: string, subscription: {
        endpoint: string;
        keys: {
            p256dh: string;
            auth: string;
        };
    }): Promise<PushSubscription>;
    removeSubscription(userId: string): Promise<void>;
    private sendPush;
    sendClassReminders(): Promise<void>;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var PushService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PushService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const schedule_1 = require("@nestjs/schedule");
const webpush = require("web-push");
const push_subscription_entity_1 = require("./push-subscription.entity");
const user_entity_1 = require("../users/entities/user.entity");
let PushService = PushService_1 = class PushService {
    constructor(subscriptionRepository, scheduleRepository) {
        this.subscriptionRepository = subscriptionRepository;
        this.scheduleRepository = scheduleRepository;
        this.logger = new common_1.Logger(PushService_1.name);
        webpush.setVapidDetails('mailto:agata@lingolandias.net', process.env.VAPID_PUBLIC_KEY, process.env.VAPID_PRIVATE_KEY);
    }
    getVapidPublicKey() {
        return { publicKey: process.env.VAPID_PUBLIC_KEY };
    }
    async saveSubscription(userId, subscription) {
        await this.subscriptionRepository.delete({ userId });
        const sub = this.subscriptionRepository.create({
            userId,
            endpoint: subscription.endpoint,
            p256dh: subscription.keys.p256dh,
            auth: subscription.keys.auth,
        });
        return this.subscriptionRepository.save(sub);
    }
    async removeSubscription(userId) {
        await this.subscriptionRepository.delete({ userId });
    }
    async sendPush(userId, title, body) {
        const subscription = await this.subscriptionRepository.findOne({
            where: { userId },
        });
        if (!subscription)
            return;
        const pushSubscription = {
            endpoint: subscription.endpoint,
            keys: { p256dh: subscription.p256dh, auth: subscription.auth },
        };
        try {
            await webpush.sendNotification(pushSubscription, JSON.stringify({ title, body, icon: '/logo.png' }));
        }
        catch (err) {
            this.logger.error(`Push failed for user ${userId}: status=${err.statusCode} body=${JSON.stringify(err.body)}`);
            if (err.statusCode === 410 || err.statusCode === 404) {
                await this.subscriptionRepository.delete({ userId });
            }
        }
    }
    async sendClassReminders() {
        const now = new Date();
        const target = new Date(now.getTime() + 10 * 60 * 1000);
        const dayNames = [
            'Sunday', 'Monday', 'Tuesday', 'Wednesday',
            'Thursday', 'Friday', 'Saturday',
        ];
        const dayOfWeek = dayNames[target.getUTCDay()];
        const targetHour = target.getUTCHours();
        const targetMinute = target.getUTCMinutes();
        const upcomingSchedules = await this.scheduleRepository
            .createQueryBuilder('schedule')
            .leftJoinAndSelect('schedule.student', 'student')
            .leftJoinAndSelect('student.settings', 'studentSettings')
            .leftJoinAndSelect('schedule.teacher', 'teacher')
            .leftJoinAndSelect('teacher.settings', 'teacherSettings')
            .where('schedule.dayOfWeek = :dayOfWeek', { dayOfWeek })
            .andWhere('EXTRACT(HOUR FROM schedule."startTime") = :hour', { hour: targetHour })
            .andWhere('EXTRACT(MINUTE FROM schedule."startTime") = :minute', { minute: targetMinute })
            .getMany();
        for (const schedule of upcomingSchedules) {
            if (schedule.student?.settings?.classReminders) {
                await this.sendPush(schedule.student.id, 'Class starting in 10 minutes!', `Your class with ${schedule.teacherName} is about to start. Get ready!`);
                this.logger.log(`Reminder sent to student ${schedule.studentName}`);
            }
            if (schedule.teacher?.settings?.classReminders) {
                await this.sendPush(schedule.teacher.id, 'Class starting in 10 minutes!', `Your class with ${schedule.studentName} is about to start. Get ready!`);
                this.logger.log(`Reminder sent to teacher ${schedule.teacherName}`);
            }
        }
    }
};
exports.PushService = PushService;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_MINUTE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PushService.prototype, "sendClassReminders", null);
exports.PushService = PushService = PushService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(push_subscription_entity_1.PushSubscription)),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.Schedule)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], PushService);
//# sourceMappingURL=push.service.js.map
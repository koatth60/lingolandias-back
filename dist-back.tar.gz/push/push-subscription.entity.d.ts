import { User } from '../users/entities/user.entity';
export declare class PushSubscription {
    id: string;
    endpoint: string;
    p256dh: string;
    auth: string;
    userId: string;
    user: User;
}

export declare class PushModule {
}

import { PushService } from './push.service';
export declare class PushController {
    private readonly pushService;
    constructor(pushService: PushService);
    getVapidPublicKey(): {
        publicKey: string;
    };
    subscribe(req: any, body: any): Promise<import("./push-subscription.entity").PushSubscription>;
    unsubscribe(req: any): Promise<void>;
}

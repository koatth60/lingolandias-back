import { MailerService } from '@nestjs-modules/mailer';
export declare class MailService {
    private mailerService;
    private readonly logger;
    constructor(mailerService: MailerService);
    sendUserWelcomeEmail(name: string, email: string, password: string): Promise<void>;
    sendUserResetPasswordEmail(name: string, email: string, resetUrl: string): Promise<void>;
    sendPasswordChangedEmail(name: string, email: string): Promise<void>;
    sendSupportEmail(data: {
        name: string;
        lastName: string;
        email: string;
        language: string;
        subject: string;
        message: string;
    }): Promise<void>;
}

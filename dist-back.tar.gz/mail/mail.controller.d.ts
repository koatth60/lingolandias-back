import { MailService } from './mail.service';
declare class SupportEmailDto {
    name: string;
    lastName: string;
    email: string;
    language: string;
    subject: string;
    message: string;
}
export declare class MailController {
    private readonly mailService;
    constructor(mailService: MailService);
    sendSupport(body: SupportEmailDto): Promise<{
        message: string;
    }>;
}
export {};

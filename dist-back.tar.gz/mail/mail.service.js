"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MailService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailService = void 0;
const common_1 = require("@nestjs/common");
const dotenv_1 = require("dotenv");
const mailer_1 = require("@nestjs-modules/mailer");
(0, dotenv_1.config)({ path: '.env.development.development' });
let MailService = MailService_1 = class MailService {
    constructor(mailerService) {
        this.mailerService = mailerService;
        this.logger = new common_1.Logger(MailService_1.name);
    }
    async sendUserWelcomeEmail(name, email, password) {
        try {
            await this.mailerService.sendMail({
                to: email,
                subject: 'Welcome to Lingolandias',
                template: './welcome',
                context: {
                    email: email,
                    name: name,
                    password: password,
                },
            });
            this.logger.log(`Welcome email sent to ${email}`);
        }
        catch (error) {
            this.logger.error(`Failed to send welcome email to ${email}`, error.stack);
            throw new Error(`Failed to send email: ${error.message}`);
        }
    }
    async sendUserResetPasswordEmail(name, email, resetUrl) {
        try {
            await this.mailerService.sendMail({
                to: email,
                subject: 'Password Reset Request',
                template: './password-reset',
                context: {
                    name: name,
                    resetUrl: resetUrl,
                },
            });
            this.logger.log(`[DEBUG] Password reset email simulated for ${email}`);
        }
        catch (error) {
            this.logger.error(`Failed to send email to ${email}`, error.stack);
            throw new common_1.InternalServerErrorException('Email service unavailable');
        }
    }
    async sendPasswordChangedEmail(name, email) {
        try {
            await this.mailerService.sendMail({
                to: email,
                subject: 'Your password was changed',
                template: './password-changed',
                context: {
                    name: name,
                },
            });
            this.logger.log(`Password changed email sent to ${email}`);
        }
        catch (error) {
            this.logger.error(`Failed to send password changed email to ${email}`, error.stack);
        }
    }
    async sendSupportEmail(data) {
        try {
            await this.mailerService.sendMail({
                to: 'agata@lingolandias.net',
                subject: `Lingolandias Platform Support - ${data.subject}`,
                template: './support-request',
                context: {
                    name: data.name,
                    lastName: data.lastName,
                    email: data.email,
                    language: data.language,
                    subject: data.subject,
                    message: data.message,
                },
            });
            this.logger.log(`Support email sent from ${data.email}`);
        }
        catch (error) {
            this.logger.error(`Failed to send support email from ${data.email}`, error.stack);
            throw new common_1.InternalServerErrorException('Failed to send support email');
        }
    }
};
exports.MailService = MailService;
exports.MailService = MailService = MailService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [mailer_1.MailerService])
], MailService);
//# sourceMappingURL=mail.service.js.map
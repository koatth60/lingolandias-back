import { OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { ChatsRepository } from './chat/chats.repository';
import { OnModuleInit } from '@nestjs/common';
import { UnreadCounterService } from './chat/unread-counter.service';
import { Repository } from 'typeorm';
import { User } from './users/entities/user.entity';
export declare class VideoCallsGateway implements OnGatewayConnection, OnGatewayDisconnect, OnModuleInit {
    private readonly chatsRepository;
    private readonly unreadCounterService;
    private readonly userRepo;
    private readonly counterStrategies;
    private readonly validLanguages;
    private readonly uuidRegex;
    private readonly socketToUser;
    private readonly userSockets;
    server: Server;
    constructor(chatsRepository: ChatsRepository, unreadCounterService: UnreadCounterService, userRepo: Repository<User>);
    onModuleInit(): Promise<void>;
    handleConnection(socket: Socket): void;
    handleDisconnect(socket: Socket): Promise<void>;
    handleRegisterUser(socket: Socket, data: {
        userId: string;
    }): void;
    notifyUserOnline(user: any): void;
    notifyUserOffline(user: any): void;
    notifyScheduleUpdated(payload: {
        studentId: string;
        action: 'add' | 'remove' | 'modify';
        schedule?: any;
        eventIds?: string[];
    }): void;
    notifyStudentAssigned(payload: {
        teacherId: string;
        studentId: string;
        schedules: any[];
        student: any;
        teacher: any;
    }): void;
    notifyStudentRemoved(payload: {
        teacherId: string;
        studentIds: string[];
        deletedScheduleIds: string[];
    }): void;
    handleJoinRoom(socket: Socket, data: {
        username: string;
        room: string;
    }): void;
    handleWebRTCSignaling(socket: Socket, data: any): void;
    handleEditNormalChat(socket: Socket, data: {
        messageId: string;
        room: string;
        newMessage: string;
    }): Promise<void>;
    handleEditGlobalChat(socket: Socket, data: {
        messageId: string;
        room: string;
        newMessage: string;
    }): Promise<void>;
    handleClearNormalChat(socket: Socket, data: {
        room: string;
    }): Promise<void>;
    handleNotifyRead(socket: Socket, data: {
        room: string;
    }): void;
    handleDeleteGlobalChat(socket: Socket, data: {
        messageId: string;
        room: string;
    }): Promise<void>;
    handleDeleteNormalChat(socket: Socket, data: {
        messageId: string;
        room: string;
    }): Promise<void>;
    handleChat(socket: Socket, data: {
        username: string;
        email: string;
        room: string;
        message: string;
        userUrl?: string;
    }): Promise<void>;
    handleGlobalChat(socket: Socket, data: {
        username: string;
        email: string;
        room: string;
        message: string;
        userUrl?: string;
    }): Promise<void>;
    handleSupportChat(socket: Socket, data: {
        username: string;
        email: string;
        room: string;
        message: string;
        userRole?: string;
        userUrl?: string;
    }): Promise<void>;
    handleDeleteSupportChat(socket: Socket, data: {
        messageId: string;
    }): Promise<void>;
    private getCounterField;
    private capitalize;
    private parseId;
    private isValidUUID;
}
